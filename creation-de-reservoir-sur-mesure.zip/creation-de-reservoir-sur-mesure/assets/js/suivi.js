document.addEventListener('DOMContentLoaded', function () {
    const statuses = window.ispagStatusChoices || [];

    document.querySelectorAll('.editable-status').forEach(btn => {
        btn.addEventListener('click', () => {
            if (btn.classList.contains('non-editable')) return; // 🛑 stop si non autorisé
            if (btn.querySelector('select')) return;

            const current = btn.dataset.current;
            const deal = btn.dataset.deal;
            const phase = btn.dataset.phase;

            const select = document.createElement('select');
            select.style.padding = '4px';
            select.style.borderRadius = '4px';

            // Ajouter une option vide si rien sélectionné
            const empty = document.createElement('option');
            empty.value = '';
            empty.textContent = '—';
            select.appendChild(empty);

            statuses.forEach(st => {
                const opt = document.createElement('option');
                opt.value = st.id;
                opt.textContent = st.name;
                opt.style.backgroundColor = st.color;
                if (st.id === current) opt.selected = true;
                select.appendChild(opt);
            });

            select.addEventListener('change', () => {
                const selected = select.value;
                fetch(ajaxurl, {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        action: 'ispag_update_phase_status',
                        deal_id: deal,
                        slug_phase: phase,
                        status_id: selected
                    })
                })
                .then(res => res.json())
                .then(res => {
                    if (res.success) {
                        btn.innerText = res.data.name;
                        btn.style.backgroundColor = res.data.color;
                        btn.dataset.current = selected;
                    }
                });
            });

            btn.innerHTML = '';
            btn.appendChild(select);
        });
    });
});
