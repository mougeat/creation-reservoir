document.addEventListener("DOMContentLoaded", function () {
    const tabs = document.querySelectorAll(".tab-titles li");
    const contents = document.querySelectorAll(".tab-content");

    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            tabs.forEach(t => t.classList.remove("active"));
            contents.forEach(c => c.classList.remove("active"));

            tab.classList.add("active");
            document.getElementById(tab.dataset.tab).classList.add("active");
        });
    });

    document.querySelectorAll('.ispag-inline-edit').forEach(el => {
    if (!el.querySelector('.edit-icon')) return;

    el.addEventListener('click', () => {
      const currentValue = el.dataset.value;
      const fieldName = el.dataset.name;
      const dealId = el.dataset.deal;
      const source = el.dataset.source || 'delivery'; // par défaut "delivery"

      const input = document.createElement('input');
      input.type = 'text';
      input.value = currentValue;
      input.style.width = '200px';

      console.log(dealId);

      input.addEventListener('blur', () => {
        fetch(ajaxurl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({
            action: 'ispag_inline_edit_field',
            field: fieldName,
            value: input.value,
            deal_id: dealId,
            source: source
          })
        })
        .then(res => res.json())
        .then(res => {
          if (res.success) {
            el.dataset.value = input.value;
            el.innerHTML = input.value + ' <span class="edit-icon">✏️</span>';
          } else {
            alert('Erreur : ' + res.data);
            el.innerHTML = currentValue + ' <span class="edit-icon">✏️</span>';
          }
        });
      });

      el.innerHTML = '';
      el.appendChild(input);
      input.focus();
    });
  });

});
