document.addEventListener("DOMContentLoaded", function () {
    attachEditModalEvents();
    attachViewModalEvents();

    // ferme la modale
    const modal = document.getElementById("ispag-modal");
    const closeBtn = document.querySelector(".ispag-modal-close");
    closeBtn.onclick = () => modal.style.display = "none";
    window.onclick = (e) => { if (e.target === modal) modal.style.display = "none"; };

    // Bouton "Voir"
    document.querySelectorAll('.ispag-btn-view').forEach(btn => {
        btn.addEventListener("click", () => {
            const articleId = btn.dataset.articleId;

            fetch(ajaxurl, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: new URLSearchParams({
                    action: 'ispag_load_article_modal',
                    article_id: articleId
                })
            })
            .then(res => res.text())
            .then(html => {
                document.getElementById("ispag-modal-body").innerHTML = html;
                modal.style.display = "block";
                attachViewModalEvents();
                attachEditModalEvents();
            });
        });
    });


    // Bouton "Éditer"
    $('.ispag-btn-edit').on('click', function () {
        const articleId = $(this).data('article-id');

        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'ispag_load_article_edit_modal',
                article_id: articleId
            },
            success: function (response) {
                $('#ispag-modal-body').html(response);
                $('#ispag-modal').show();

                attachEditModalEvents(); // 🔥 Ajout ici
                attachViewModalEvents();
            },
            error: function () {
                alert('Erreur lors du chargement du formulaire.');
            }
        });
    });

    $(document).on('submit', '.ispag-edit-article-form', function (e) {
        e.preventDefault();

        const form = $(this);
        const articleId = form.data('article-id');
        const is_secondary = form.data('data-level-secondary');
        const dealId = getUrlParam('deal_id'); // 🔹 tu dois avoir cette fonction déjà dispo
        const formData = new URLSearchParams(form.serialize());

        // Ajout manuel de certains champs
        if (!articleId && dealId) {
            formData.append('deal_id', dealId);
        }

        // Construction du payload
        const payload = {
            action: 'ispag_save_article',
            article_id: articleId || 0
        };

        for (const [key, value] of formData.entries()) {
            payload[key] = value;
        }

        $.post(ajaxurl, payload)
            .done(response => {
                console.log('Enregistrement :', response);
                $('#ispag-modal').hide();

                if (articleId) {
                    // 🔁 Cas édition : on recharge la ligne
                    $.post(ajaxurl, {
                        action: 'ispag_reload_article_row',
                        is_secondary: is_secondary,
                        article_id: articleId
                    }, function (html) {
                        $(`[data-article-id="${articleId}"]`).replaceWith(html);
                        attachEditModalEvents();
                        attachViewModalEvents();
                    });
                } 
                else {
                    // 🔁 Cas création : recharger toute la page ou actualiser la liste ?
                    // location.reload(); // ou appelle une fonction de refresh
                }

            })
            .fail(err => {
                console.error('Erreur enregistrement :', err);
                alert('Erreur lors de la sauvegarde');
            });
    });



    function attachEditModalEvents() {
        const titleInput = document.getElementById('article-title');
        if (titleInput) {
            // Utiliser 'change' à la place de 'input' si tu veux déclencher moins souvent
            titleInput.addEventListener('change', () => {
                const selectedTitle = titleInput.value.trim();
                const articleType = titleInput.dataset.type;

                if (!selectedTitle || !articleType) return;

                fetch(ajaxurl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        action: 'ispag_get_standard_article_info',
                        title: selectedTitle,
                        type: articleType
                    })
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        const article = data.data['article'];
                        console.log('Article :', article);
                        document.querySelector('[name="description"]').value = article['description_ispag'] || '';
                        document.querySelector('[name="sales_price"]').value = article['sales_price'] || '';
                        
                        const supplierField = document.querySelector('[name="supplier"]');
                        const supplierList = document.getElementById('supplier-list');

                        if (supplierField && supplierList) {
                            // On vide la datalist avant de la remplir
                            supplierList.innerHTML = '';

                            if (Array.isArray(article.suppliers)) {
                                article.suppliers.forEach(supplier => {
                                    const option = document.createElement('option');
                                    option.value = supplier;
                                    supplierList.appendChild(option);
                                });

                                // Pré-remplir le champ avec le premier fournisseur si dispo
                                if (article.suppliers.length == 0) {
                                    supplierField.value = article.suppliers[0];
                                }
                            }
                        }
                    } else if (data.error) {
                        alert(data.error);
                    }
                })
                .catch(() => alert('Erreur réseau ou serveur.'));
            });
        }

        // Rebind des boutons éditer (jQuery)
        $('.ispag-btn-edit').off('click').on('click', function () {
            const articleId = $(this).data('article-id');

            $.ajax({
                url: ajaxurl,
                method: 'POST',
                data: {
                    action: 'ispag_load_article_edit_modal',
                    article_id: articleId
                },
                success: function (response) {
                    $('#ispag-modal-body').html(response);
                    $('#ispag-modal').show();

                    // Réattache les events pour la nouvelle modale
                    attachEditModalEvents();
                },
                error: function () {
                    alert('Erreur lors du chargement du formulaire.');
                }
            });
        });
    }


    function attachViewModalEvents() {
        const modal = document.getElementById("ispag-modal");

        document.querySelectorAll('.ispag-btn-view').forEach(btn => {
            btn.removeEventListener("click", handleViewClick); // évite les doublons
            btn.addEventListener("click", handleViewClick);
        });

        function handleViewClick(e) {
            const articleId = e.currentTarget.dataset.articleId;

            fetch(ajaxurl, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: new URLSearchParams({
                    action: 'ispag_load_article_modal',
                    article_id: articleId
                })
            })
            .then(res => res.text())
            .then(html => {
                document.getElementById("ispag-modal-body").innerHTML = html;
                modal.style.display = "block";
            });
        }
    }
    // document.getElementById('ispag-add-article').addEventListener('click', function () {
    //     fetch(ajaxurl, {
    //         method: 'POST',
    //         headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    //         body: new URLSearchParams({
    //             action: 'ispag_open_new_article_modal'
    //         })
    //     })
    //     .then(res => res.text())
    //     .then(html => {
    //         document.getElementById("ispag-modal-body").innerHTML = html;
    //         document.getElementById("ispag-modal").style.display = "block";
    //     });
    // });

    document.getElementById('ispag-add-article').addEventListener('click', function () {
        fetch(ajaxurl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                action: 'ispag_open_new_article_modal'
            })
        })
        .then(res => res.text())
        .then(html => {
            document.getElementById("ispag-modal-body").innerHTML = html;
            document.getElementById("ispag-modal").style.display = "block";
            

            // 🟡 Attacher l'écouteur après le rendu du select
            const typeSelect = document.getElementById("new-article-type");
            const dealId = getUrlParam('deal_id');
            if (typeSelect) {
                typeSelect.addEventListener('change', function () {
                    const typeId = this.value;
                    if (!typeId || !dealId) return;

                    fetch(ajaxurl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({
                            action: 'ispag_load_article_create_modal',
                            type_id: typeId,
                            deal_id: dealId
                        })
                    })
                    .then(res => res.text())
                    .then(html => {
                        // document.getElementById("ispag-product-type-selector").style.display = "none";
                        document.getElementById("new-article-form-container").innerHTML = html;
                        attachEditModalEvents();
                    });
                });
            }
        });
    });

    $(document).on('click', '.ispag-btn-delete', function () {
    const articleId = $(this).data('article-id');
    if (!confirm(ispag_texts.confirm_delete_article + ' ?')) return;

        $.post(ajaxurl, {
            action: 'ispag_delete_article',
            article_id: articleId
        })
        .done(response => {
            if (response.success) {
                $(`[data-article-id="${articleId}"]`).remove(); // supprime le bloc HTML
            } else {
                alert(response.data.message || 'Erreur lors de la suppression');
            }
        })
        .fail(() => {
            alert('Erreur serveur');
        });
    });


});



function getUrlParam(key) {
    const params = new URLSearchParams(window.location.search);
    return params.get(key);
}