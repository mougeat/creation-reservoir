jQuery(document).ready(function($) {
  $('#AssociatedContactIDs').on('change', function() {
    const user_id = $(this).val();
    
    if (!user_id) return;

    console.log(user_id);

    $.ajax({
      url: ispag_ajax_object.ajax_url,
      type: 'POST',
      dataType: 'json',
      data: {
        action: 'get_company_by_user_id',
        user_id: user_id,
        nonce: ispag_ajax_object.nonce
      },
      success: function(response) {
        console.log(response);
        if (response.success) {
                console.log('client_Id:', response.data.client_id);
                $('select[name="AssociatedCompanyID"]').val(response.data.client_id.toString().trim());
                const dealId = response.data.hubspot_deal_id;
                console.log(dealId);
                // window.location.href = `${window.location.origin}/liste-des-projets/?deal_id=${dealId}`;
        }
        
      },
        error: function (error){
            console.log('ERREUR', error);
        }
    
    });
  });
});