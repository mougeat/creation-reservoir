jQuery(document).ready(function($) {
    $('#creation-reservoir-app').append('<p>Plugin actif et prêt !</p>');
});
