<?php

defined('ABSPATH') or die();

class ISPAG_Achat_Manager {

    public static function init() {
        add_shortcode('ispag_achats', [self::class, 'shortcode_achats']);
        add_action('wp_enqueue_scripts', [self::class, 'enqueue_assets']);
    }

    public static function enqueue_assets() {
        wp_enqueue_style('ispag-style', plugin_dir_url(__FILE__) . '../assets/css/style.css');

        wp_enqueue_script('ispag-scroll-achats', plugin_dir_url(__FILE__) . '../assets/js/infinite-scroll-achat.js', [], false, true);
        wp_localize_script('ispag-scroll-achats', 'ajaxurl', admin_url('admin-ajax.php'));

        wp_localize_script('ispag-scroll-achats', 'ispagVars', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'loading_text' => __('Loading', 'creation-reservoir'),
            'all_loaded_text' => __('All projects are loaded', 'creation-reservoir'),
        ]);
    }

    public static function shortcode_achats($atts) {
        $search_query = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';

        $html = '<form method="get" style="margin-bottom: 20px;">
            <input type="text" name="search" placeholder="' . __('Search', 'creation-reservoir') . ' ..." value="' . esc_attr($search_query) . '" />
            <button type="submit">' . __('Search', 'creation-reservoir') . '</button>
        </form>';

        $html .= '<div class="ispag-table-wrapper">';
        $html .= '<table class="ispag-project-table">';
        $html .= '<thead><tr>
            <th>#</th>
            <th>' . __('Reference', 'creation-reservoir') . '</th>  
            <th>' . __('Nb', 'creation-reservoir') . '</th>
            <th>' . __('Order date', 'creation-reservoir') . '</th>
            <th>' . __('Delivery date', 'creation-reservoir') . '</th>
            <th>' . __('Supplier', 'creation-reservoir') . '</th>
            <th>' . __('Confirmation de commande', 'creation-reservoir') . '</th>
            <th>' . __('State', 'creation-reservoir') . '</th>
        </tr></thead>';
        $html .= '<tbody id="achats-list"></tbody>';
        $html .= '</table></div>';
        $html .= '<div id="scroll-loader" style="height: 40px;"></div>';

        return $html;
    }

    public static function render_achat_row($achat, $index = 0) {
        $date = date('d.m.Y', $achat->TimestampDateCreation);
        $reception = $achat->TimestampDateLivraisonConfirme ? date('d.m.Y', $achat->TimestampDateLivraisonConfirme) : '-';
        $bgcolor = !empty($achat->color) ? esc_attr($achat->color) : '#ccc';

        return '
            <tr>
                <td style="background-color:#D1E7DD;">' . ($index + 1) . '</td>
                <td><a href="' . esc_url($achat->project_url) . '" target="_blank">' . esc_html($achat->RefCommande) . '</a></td>
                <td>P' . esc_html($achat->NrCommande) . '</td>
                <td>' . esc_html($date) . '</td>
                <td>' . esc_html($reception) . '</td>
                <td>' . esc_html($achat->Fournisseur) . '</td>
                <td>' . esc_html($achat->ConfCmdFournisseur) . '</td>
                <td><span class="badge" style="background-color:' . $bgcolor . '; opacity: 0.8;">' . esc_html__($achat->Etat, 'creation-reservoir') . '</span>    </td>
                
            </tr>
        ';
    }
}


add_action('wp_ajax_ispag_load_more_achats', 'ispag_load_more_achats');
add_action('wp_ajax_nopriv_ispag_load_more_achats', 'ispag_load_more_achats');

function ispag_load_more_achats() {
    $offset = intval($_POST['offset']);
    $limit = 20;
    $search = sanitize_text_field($_POST['search']);
    $user_id = get_current_user_id();

    $can_view_all = current_user_can('view_supplier_order');
    $can_view_own = current_user_can('read_orders');

    $repo = new ISPAG_Achat_Repository();
    $achats = [];

    if ($can_view_all) {
        $achats = $repo->get_achats(null, true, $search, $offset, $limit);
    } elseif ($can_view_own) {
        $achats = $repo->get_achats($user_id, false, $search, $offset, $limit);
    }

    $html = '';
    foreach ($achats as $i => $achat) {
        $html .= ISPAG_Achat_Manager::render_achat_row($achat, $offset + $i);
    }

    wp_send_json_success(['html' => $html, 'has_more' => count($achats) === $limit]);
}
