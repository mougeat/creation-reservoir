<?php
defined('ABSPATH') or die();

class ISPAG_Projet_Repository {

    protected $table_projects;
    protected $table_details;
    protected $table_users;
    protected $table_fournisseurs;
    protected  $table_prestations;
    protected $wpdb;
    private $only_active;


    public function __construct($only_active = false) {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->table_projects = $wpdb->prefix . 'achats_liste_commande';
        $this->table_details = $wpdb->prefix . 'achats_details_commande';
        $this->table_users = $wpdb->prefix . 'users';
        $this->table_fournisseurs = $wpdb->prefix . 'achats_fournisseurs';
        $this->table_prestations = $wpdb->prefix . 'achats_type_prestations';
        $this->only_active = $only_active;

    }

    /**
     * Récupère projets ou offres.
     * 
     * @param bool $is_quotation  true = offre, false = projet
     * @param int|null $user_id id utilisateur pour filtrer (si pas admin)
     * @param bool $all true = sans filtre, false = filtre par utilisateur
     * 
     * @return array
     */
    public function get_projects_or_offers($is_quotation = false, $user_id = null, $all = false, $search = '', $offset = 0, $limit = 20) {

        $query = "
            SELECT 
                p.*, 
                SUM(d.sales_price * d.Qty) AS prix_total, 
                (SUM(d.sales_price * d.Qty) - d.discount * SUM(d.sales_price * d.Qty) /100) AS prix_net
            FROM {$this->table_projects} p
            LEFT JOIN {$this->table_details} d ON p.hubspot_deal_id = d.hubspot_deal_id
            LEFT JOIN {$this->table_fournisseurs} f ON f.Id = p.AssociatedCompanyID
            LEFT JOIN {$this->table_users} u ON u.Id = p.AssociatedContactIDs
            WHERE ";

        // Offre ou projet ?
        if ($is_quotation) {
            $query .= "p.isQotation = 1";
        } else {
            $query .= "(p.isQotation IS NULL OR p.isQotation = 0)";
        }

        if ($this->only_active) {
            $query .= " AND CmdActif = 1";
        }

        $query_params = [];

        // Si utilisateur limité
        if (!$all && $user_id) {
            $query .= " AND (FIND_IN_SET(%d, REPLACE(p.AssociatedContactIDs, ';', ',')) > 0 OR p.Abonne LIKE %s)";
            $query_params[] = $user_id;
            $query_params[] = '%;' . $user_id . ';%';
        }

        // Filtrage par recherche (si fourni)
        if (!empty($search)) {
            $query .= " AND (p.ObjetCommande LIKE %s OR u.display_name LIKE %s OR f.Fournisseur LIKE %s OR p.hubspot_deal_id LIKE %s)";
            // $query .= " AND (p.ObjetCommande LIKE %s )";
            $like = '%' . $search . '%';
            $query_params[] = $like;
            $query_params[] = $like;
            $query_params[] = $like;
            $query_params[] = $like;
        } else {
            // Sinon, filtrer par date
            $query .= " AND p.TimestampDateCommande > UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 6 MONTH))";
            
        }

        $query .= " GROUP BY p.Id ORDER BY p.TimestampDateCommande DESC LIMIT %d OFFSET %d";
        $query_params[] = $limit;
        $query_params[] = $offset;

        $prepared = $this->wpdb->prepare($query, ...$query_params);
        $results = $this->wpdb->get_results($prepared);

        if (!$results) {
            return [];
        }

        // 1. Extraire tous les hubspot_deal_id
        $hubspot_ids = array_map(fn($p) => (int)$p->hubspot_deal_id, $results);

        // 2. Précharger les données de livraison
        $progress_bar = new ISPAG_Projet_Progress_Bar();
        $delivery_data = $progress_bar->preload_delivery_data($hubspot_ids);
        // Juste après avoir récupéré $results et extrait $hubspot_ids
        $next_phases = (new ISPAG_Projet_Suivi())->preload_next_phases($hubspot_ids, $is_quotation);

        // 3. Compléter les projets
        $base_url = trailingslashit(get_site_url()) . 'liste-des-projets/';
        $base_url_dev = trailingslashit(get_site_url()) . 'details-du-projet/';
        $base_purchase_url = trailingslashit(get_site_url()) . 'details-du-projet/';

        foreach ($results as $p) {
            $p->contact_name = $this->get_contact_names($p->AssociatedContactIDs);
            $p->nom_entreprise = self::get_company_name_from_id($p->AssociatedCompanyID);
            $p->project_url = esc_url(add_query_arg('deal_id', $p->hubspot_deal_id, $base_url));
            $p->project_url_dev = esc_url(add_query_arg('deal_id', $p->hubspot_deal_id, $base_url_dev));
            $current_user_id = get_current_user_id();
            $p->is_project_owner = self::is_user_project_owner($p, $current_user_id);


            // Barres de progression
            $p->bar_product = $progress_bar->get_delivery_progress_bar_from_data($p->hubspot_deal_id, 'Product', $delivery_data);
            $p->bar_welding = $progress_bar->get_delivery_progress_bar_from_data($p->hubspot_deal_id, 'Welding', $delivery_data);
            $p->bar_isol    = $progress_bar->get_delivery_progress_bar_from_data($p->hubspot_deal_id, 'Isol', $delivery_data);
            if (!isset($next_phases[$p->hubspot_deal_id])) {
                error_log('[ISPAG] Aucune phase pour projet : ' . $p->hubspot_deal_id);
            }
            $p->next_phase = $next_phases[$p->hubspot_deal_id] ?? null;
        }

        return $results;
    }


    public function preload_delivery_data($hubspot_deal_ids) {
        global $wpdb;

        $placeholders = implode(',', array_fill(0, count($hubspot_deal_ids), '%d'));

        $results = $wpdb->get_results(
            $wpdb->prepare("
                SELECT 
                    td.hubspot_deal_id,
                    td.TimestampDateDeLivraison,
                    td.TimestampDateDeLivraisonFin,
                    td.Livre,
                    ttp.prestation
                FROM {$this->table_details} td
                LEFT JOIN {$this->table_prestations} ttp ON ttp.Id = td.Type
                WHERE td.hubspot_deal_id IN ($placeholders)
            ", ...$hubspot_deal_ids),
            ARRAY_A
        );

        // Réorganiser les données pour un accès facile
        $grouped = [];
        foreach ($results as $row) {
            $deal_id = $row['hubspot_deal_id'];
            $type = $row['prestation'];
            $grouped[$deal_id][$type][] = $row;
        }

        return $grouped;
    }

    

    /**
     * Récupère noms des contacts depuis la string ;id1;id2; ou CSV.
     */
    protected function get_contact_names($contact_ids) {
        $ids = [];

        // Nettoyer et splitter IDs (support ;id;id; ou CSV)
        $contact_ids = trim($contact_ids);
        if (empty($contact_ids)) {
            return '';
        }
        if (strpos($contact_ids, ';') !== false) {
            $parts = explode(';', $contact_ids);
            foreach ($parts as $part) {
                $id = intval($part);
                if ($id > 0) {
                    $ids[] = $id;
                }
            }
        } else {
            // CSV classique
            $parts = explode(',', $contact_ids);
            foreach ($parts as $part) {
                $id = intval($part);
                if ($id > 0) {
                    $ids[] = $id;
                }
            }
        }

        if (empty($ids)) return '';

        global $wpdb;

        // Récupérer display_name des WP users
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));
        $sql = "SELECT ID, display_name FROM {$wpdb->users} WHERE ID IN ($placeholders)";
        $users = $wpdb->get_results($wpdb->prepare($sql, ...$ids));

        if (!$users) return '';

        $names = array_map(fn($u) => $u->display_name, $users);

        return implode(', ', $names);
    }

    private static function get_company_name_from_id($company_id) {
        global $wpdb;
        $company_id = intval($company_id);
        if (!$company_id) return '';

        $table_fournisseurs = $wpdb->prefix . 'achats_fournisseurs';

        $sql = "SELECT Fournisseur FROM {$table_fournisseurs} WHERE Id = %d LIMIT 1";

        return $wpdb->get_var($wpdb->prepare($sql, $company_id)) ?? '';
    }

    public function get_project_by_deal_id($deal_id) {
        return $this->wpdb->get_row(
            $this->wpdb->prepare("SELECT * FROM {$this->table_projects} WHERE hubspot_deal_id = %d", $deal_id)
        );
    }


    public static function is_user_project_owner($deal_id = null, $user_id = null) {
        if (empty($deal_id)) return false;

        $project_repo = new ISPAG_Projet_Repository();
        $project = $project_repo->get_project_by_deal_id($deal_id);

        if (!$project || empty($project->AssociatedContactIDs)) {
            return false;
        }

        if (!$user_id) {
            $user_id = get_current_user_id();
        }

        $contact_ids = array_map('intval', array_filter(preg_split('/[;,]+/', $project->AssociatedContactIDs)));

        return in_array((int)$user_id, $contact_ids, true);
    }


}
