<?php

class ISPAG_Telegram_Notifier {
    private $bot_token;
    private $admin_chat_id;
    private $wpdb;
    private $table_subs;

    public function __construct($admin_chat_id) {
        global $wpdb;
        // $this->bot_token = $bot_token;
        $this->bot_token = '7729817427:AAFuBA0CSMDyvA2WtoRLIvzoqW31jcqVdIo';
        $this->admin_chat_id = $admin_chat_id;
        $this->wpdb = $wpdb;
        $this->table_subs = $wpdb->prefix . 'achats_telegram_subscribers';
    }

    public function send_message($message, $to_admin = true, $to_subscribers = true, $deal_id = null) {
        
        if ($to_admin) {
            $this->send_to_chat($this->admin_chat_id, $message);
        }

            if ($to_subscribers) {
                $subscribers = $this->get_subscribers($deal_id);
                
                foreach ($subscribers as $sub) {
                    if ($sub->chat_id != $this->admin_chat_id) {
                        $this->send_to_chat($sub->chat_id, $message);
                    }
                }
            }
        
    }

    private function send_to_chat($chat_id, $message) {
        error_log('[TELEGRAM] Envoi message à ' . $chat_id . ': ' . $message);
        $url = "https://api.telegram.org/bot{$this->bot_token}/sendMessage";
        $params = [
            'chat_id' => $chat_id,
            'text' => $message,
            'parse_mode' => 'HTML'
        ];

        // wp_remote_post($url, [
        //     'body' => $params,
        //     'timeout' => 10,
        // ]);

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);

        $response = curl_exec($ch);

        if ($response === false) {
            $error = curl_error($ch);
            curl_close($ch);
            echo "❌ Erreur cURL : $error\n";
            return false;
        }

        curl_close($ch);

    
    }

    public function get_subscribers() {
        if(!empty($deal_id)){
            return $this->wpdb->get_results("SELECT chat_id FROM {$this->table_subs}");
        }
    }

    public function add_subscriber($chat_id, $display_name = '', $is_admin = 0) {
        $this->wpdb->replace($this->table_subs, [
            'chat_id' => $chat_id,
            'display_name' => $display_name,
            'is_admin' => $is_admin,
        ]);
    }

    public function remove_subscriber($chat_id) {
        $this->wpdb->delete($this->table_subs, ['chat_id' => $chat_id]);
    }

    public function get_message($slug, $deal_id) {
        

        $table = $this->wpdb->prefix . 'achats_template_mail';

        $query = "
            SELECT telegram 
            FROM $table 
            WHERE message_family = %s AND message_type = %s 
            ORDER BY Id DESC 
            LIMIT 1
        ";

        $project = new ISPAG_Projet_Repository();
        $project_datas = $project->get_projects_or_offers(false, null, false, $deal_id);
        

        $sql = $this->wpdb->prepare($query, 'project', $slug);
        $result = $this->wpdb->get_var($sql);
        if (!empty($project_datas) && is_array($project_datas)) {
            $current_user = wp_get_current_user();
            $user_name = $current_user->display_name ?: 'Utilisateur';

            $first_project = $project_datas[0];
            $result = preg_replace("{PROJECT_NAME}", $first_project->ObjetCommande, $result);
            $result = preg_replace("{PROJECT_LINK}", '<a href="'.$first_project->project_url_dev.'">Voir le projet</a>', $result);
            $result = preg_replace("{USER_NAME}", $user_name, $result);  
            $result = preg_replace('{BR}', "\n", $result);
            // $result = preg_replace("\n", "\n", $result);

        }

        return $result ?: null; // null si pas trouvé
    }

}
