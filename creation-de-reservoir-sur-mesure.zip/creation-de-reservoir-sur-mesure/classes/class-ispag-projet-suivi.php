<?php

class ISPAG_Projet_Suivi {
    private $wpdb;
    private $table_suivi;
    private $table_phase;
    private $table_status;
    private $table_liste_commande;

    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $prefix = $wpdb->prefix;
        $this->table_suivi = "{$prefix}achats_suivi_phase_commande";
        $this->table_phase = "{$prefix}achats_slug_phase";
        $this->table_status = "{$prefix}achats_meta_phase_commande";
        $this->table_liste_commande = "{$prefix}achats_liste_commande";
    }

    // Enregistre un statut de phase
    public function update_phase_status($hubspot_deal_id, $slug_phase, $status_id) {
        

        // Vérifie le statut actuel
        $current = $this->wpdb->get_var($this->wpdb->prepare("
            SELECT status_id 
            FROM {$this->table_suivi} 
            WHERE hubspot_deal_id = %d 
            AND slug_phase = %s 
            ORDER BY date_modification DESC 
            LIMIT 1
        ", $hubspot_deal_id, $slug_phase));

        // Si le statut est le même, on ne fait rien
        if ((int)$current === (int)$status_id) {
            return false;
        }

        //Si le status est == 1, on envoie le mail Brevo
        if($status_id == 1){
            $Mail = new \wp_gestion\class\Mail();
            $array['template_id'] = $Mail->getBrevoTemplateId($slug_phase);
            $array['Brevo_delay_days'] = $Mail->getBrevoDelayDays($slug_phase);
            $array['brevo'] = ($status_id == 1 AND !empty($hubspot_deal_id)) ? brevo_send_email_with_pdf($hubspot_deal_id, $array['template_id'], $array['Brevo_delay_days']) : null;
        }
        
        return $this->wpdb->insert(
            $this->table_suivi,
            [
                'hubspot_deal_id' => $hubspot_deal_id,
                'slug_phase' => $slug_phase,
                'status_id' => $status_id,
                'date_modification' => current_time('mysql')
            ],
            ['%d', '%s', '%d', '%s']
        );
    }

    // Récupère le statut actuel par phase
    public function get_current_status($hubspot_deal_id, $isQuotation = false) {

        $filter_quotation = $isQuotation ? "WHERE phase.display_on_qotation = 1" : "";


        $results = $this->wpdb->get_results($this->wpdb->prepare("
            SELECT 
                phase.SlugPhase, 
                phase.TitrePhase, 
                phase.VisuClient,
                IFNULL(status.Nom, def.Nom) AS Statut, 
                IFNULL(status.Couleur, def.Couleur) AS Couleur,
                IFNULL(suivi.date_modification, '') AS date_modification
            FROM {$this->table_phase} AS phase
            LEFT JOIN (
                SELECT s1.slug_phase, s1.status_id, s1.date_modification
                FROM {$this->table_suivi} s1
                INNER JOIN (
                    SELECT slug_phase, MAX(date_modification) AS max_date
                    FROM {$this->table_suivi}
                    WHERE hubspot_deal_id = %d
                    GROUP BY slug_phase
                ) s2 ON s1.slug_phase = s2.slug_phase AND s1.date_modification = s2.max_date
                WHERE s1.hubspot_deal_id = %d
            ) AS suivi ON suivi.slug_phase = phase.SlugPhase
            LEFT JOIN {$this->table_status} AS status ON status.Id = suivi.status_id
            LEFT JOIN {$this->table_status} AS def ON def.Id = 10
            $filter_quotation
            ORDER BY phase.Ordre ASC
        ", $hubspot_deal_id, $hubspot_deal_id));

        return $results;
    }

    public function is_quotation($hubspot_deal_id) {
        return (bool) $this->wpdb->get_var($this->wpdb->prepare("
            SELECT isQotation FROM {$this->table_liste_commande} WHERE hubspot_deal_id = %d
        ", $hubspot_deal_id));
    }

    // public function get_current_status_table($hubspot_deal_id){
    //     $isQuotation = $this->is_quotation($hubspot_deal_id);
    //     $phases = $this->get_current_status($hubspot_deal_id, $isQuotation);

    //     $table_header = array(
    //         __("Date","wp_gestion"),
    //         __("Project step","wp_gestion"),
    //         __("State","wp_gestion"),
    //     );

    //     foreach ($phases as $p) {
    //         if($p->VisuClient == 1 OR (current_user_can( 'manage_order'))){
    //             $table_datas[] = array(
    //                 "date" => strtotime(esc_html($p->date_modification)),
    //                 "step" => __(esc_html($p->TitrePhase),"wp_gestion"),
    //                 "state" => $this->get_status_btn(sanitize_key($p->SlugPhase), esc_html($p->Statut), esc_attr($p->Couleur), $hubspot_deal_id) ,
    //             );
    //         }
            
    //     }
    //     $table = new Table($table_header, $table_datas);
    //     return $table->constructTable('TEST_StepTableDetail'); 

    // }

    public function get_all_statuses() {
        return $this->wpdb->get_results("SELECT Id, Nom, Couleur FROM {$this->table_status} ORDER BY sort ASC");
    }

    public function get_status_btn($slug_phase, $status, $color, $hubspot_deal_id = null) {
        $statuses = $this->get_all_statuses();
        $btn_id = 'dropdownMenuButton_' . esc_attr($slug_phase);

        $html  = '<div class="etat-projet" data-phase="' . esc_attr($slug_phase) . '" data-deal="' . esc_attr($hubspot_deal_id) . '">';
        
        // Bouton bootstrap coloré qui ouvre la dropdown
        $html .= '<button class="btn btn-sm dropdown-toggle" style="background-color:' . esc_attr($color) . '; color:#000;" type="button" id="' . $btn_id . '" data-bs-toggle="dropdown" aria-expanded="false">';
        $html .= esc_html__($status, "wp_gestion");
        $html .= '</button>';

        // Dropdown menu bootstrap
        if(current_user_can( 'manage_order')){
            $html .= '<ul class="dropdown-menu" aria-labelledby="' . $btn_id . '">';
            foreach ($statuses as $s) {
                $html .= '<li><a href="#" class="dropdown-item" data-status-id="' . intval($s->Id) . '" style="background-color:' . esc_attr($s->Couleur) . '; color:#000;">' . esc_html__($s->Nom, "wp_gestion") . '</a></li>';
            }
            $html .= '</ul>';
        }

        $html .= '</div>';

        return $html;
    }

    public function preload_next_phases(array $hubspot_ids, $is_quotation = false) {
        global $wpdb;

        if (empty($hubspot_ids)) return [];

        $ids_placeholder = implode(',', array_fill(0, count($hubspot_ids), '%d'));
        
        $excluded_status = [1, 5];
        $excluded_placeholder = implode(',', array_fill(0, count($excluded_status), '%d'));

        $phase_condition = current_user_can('manage_order') ? '1=1' : 'phase.VisuClient = 1';
        $quotation_condition = $is_quotation ? 'AND phase.display_on_qotation = 1' : '';

        $args = array_merge($hubspot_ids, $hubspot_ids, $excluded_status, $hubspot_ids, $hubspot_ids, $excluded_status);

        // Base pour les sous-requêtes avec dernières modifs
        $latest_update_join = "
            LEFT JOIN (
                SELECT s1.hubspot_deal_id, s1.slug_phase, s1.status_id
                FROM {$this->table_suivi} s1
                INNER JOIN (
                    SELECT hubspot_deal_id, slug_phase, MAX(date_modification) AS max_date
                    FROM {$this->table_suivi}
                    WHERE hubspot_deal_id IN ($ids_placeholder)
                    GROUP BY hubspot_deal_id, slug_phase
                ) s2 
                ON s1.hubspot_deal_id = s2.hubspot_deal_id 
                AND s1.slug_phase = s2.slug_phase 
                AND s1.date_modification = s2.max_date
            ) last_update 
            ON last_update.slug_phase = phase.SlugPhase 
            AND last_update.hubspot_deal_id = ps.hubspot_deal_id
        ";

        // Requête finale
        $query = "
            SELECT sub.hubspot_deal_id, sub.SlugPhase, sub.TitrePhase, sub.Statut, sub.Color
            FROM (
                SELECT 
                    phase.SlugPhase, phase.Ordre, phase.TitrePhase, phase.Color, 
                    ps.hubspot_deal_id, status.Nom AS Statut
                FROM {$this->table_phase} AS phase
                CROSS JOIN (SELECT DISTINCT hubspot_deal_id FROM {$this->table_suivi} WHERE hubspot_deal_id IN ($ids_placeholder)) ps
                $latest_update_join
                LEFT JOIN {$this->table_status} status ON status.Id = last_update.status_id
                WHERE ($phase_condition) $quotation_condition
                AND (IFNULL(status.Id, 0) = 0 OR status.Id NOT IN ($excluded_placeholder))
            ) sub
            INNER JOIN (
                SELECT hubspot_deal_id, MIN(Ordre) AS min_ordre
                FROM (
                    SELECT 
                        phase.SlugPhase, phase.Ordre, ps.hubspot_deal_id
                    FROM {$this->table_phase} AS phase
                    CROSS JOIN (SELECT DISTINCT hubspot_deal_id FROM {$this->table_suivi} WHERE hubspot_deal_id IN ($ids_placeholder)) ps
                    $latest_update_join
                    LEFT JOIN {$this->table_status} status ON status.Id = last_update.status_id
                    WHERE ($phase_condition) $quotation_condition
                    AND (IFNULL(status.Id, 0) = 0 OR status.Id NOT IN ($excluded_placeholder))
                ) filtered
                GROUP BY hubspot_deal_id
            ) min_ordres 
            ON sub.hubspot_deal_id = min_ordres.hubspot_deal_id AND sub.Ordre = min_ordres.min_ordre
        ";

        // Préparation des paramètres
        


        $prepared = $wpdb->prepare($query, ...$args);
        $rows = $wpdb->get_results($prepared);
        // if (!is_array($rows)) {
        //     error_log('[ISPAG] preload_next_phases() → Résultat SQL invalide.');
        //     $rows = [];
        // }

        // Résultat par défaut (projet terminé)
        $next_phases = [];
        foreach ($hubspot_ids as $id) {
            $next_phases[$id] = (object)[
                'SlugPhase' => 'done',
                'TitrePhase' => __('Closed', 'wp_gestion'),
                'Statut'    => '',
                'Color'     => 'success',
            ];
        }

        // Remplir avec les phases réelles si dispo
        foreach ($rows as $row) {
            $next_phases[$row->hubspot_deal_id] = $row;
        }

        return $next_phases;
    }

    // public function get_next_phase($hubspot_deal_id) {

    //     $excluded_status = [1, 5]; // statuts à exclure
    //     $placeholders = implode(',', array_fill(0, count($excluded_status), '%d'));
    //     $isQuotation = $this->is_quotation($hubspot_deal_id); // <-- on récupère le type

    //     // Condition pour filtrer selon l'utilisateur
    //     if (current_user_can('manage_order')) {
    //         $phase_condition = '1=1'; // aucune restriction
    //     } else {
    //         $phase_condition = 'phase.VisuClient = 1';
    //     }

    //     // Ajout du filtre si c'est une offre
    //     $quotation_condition = $isQuotation ? 'AND phase.display_on_qotation = 1' : '';

    //     $sql = $this->wpdb->prepare("
    //         SELECT phase.SlugPhase, phase.TitrePhase, status.Nom AS Statut, phase.Color
    //         FROM {$this->table_phase} AS phase
    //         LEFT JOIN (
    //             SELECT s1.slug_phase, s1.status_id
    //             FROM {$this->table_suivi} s1
    //             INNER JOIN (
    //                 SELECT slug_phase, MAX(date_modification) AS max_date
    //                 FROM {$this->table_suivi}
    //                 WHERE hubspot_deal_id = %d
    //                 GROUP BY slug_phase
    //             ) s2 ON s1.slug_phase = s2.slug_phase AND s1.date_modification = s2.max_date
    //             WHERE s1.hubspot_deal_id = %d
    //             ORDER BY s1.id DESC
    //         ) AS last_update ON last_update.slug_phase = phase.SlugPhase
    //         LEFT JOIN {$this->table_status} AS status ON status.Id = last_update.status_id
    //         WHERE ($phase_condition)
    //         $quotation_condition
    //         AND (IFNULL(status.Id, 0) = 0 OR status.Id NOT IN ($placeholders))
    //         ORDER BY phase.Ordre ASC
    //         LIMIT 1
    //     ", array_merge([$hubspot_deal_id, $hubspot_deal_id], $excluded_status));



    //     $result = $this->wpdb->get_row($sql);

    //     // Si aucune étape trouvée, on retourne "Terminé"
    //     if (!$result) {
    //         return (object) [
    //             'SlugPhase' => 'done',
    //             'TitrePhase' => __('Closed', 'wp_gestion'),
    //             'Statut' => '',
    //             'Color' => 'success',
    //         ];
    //     }

    //     return $result;
    // }


    public function close_project_if_all_steps_completed($hubspot_deal_id) {
        $statuses = $this->get_current_status($hubspot_deal_id);



        foreach ($statuses as $status) {
            if (!in_array($status->Statut, ["Done", "NaN"])) {
                return false; // Une étape n'est pas terminée
            }
        }

        // Toutes les étapes sont complètes, on clôture le projet
        $updated = $this->wpdb->update(
            $this->table_liste_commande,
            ['CmdActif' => 0],
            ['hubspot_deal_id' => $hubspot_deal_id],
            ['%d'],
            ['%d']
        );

        return $updated !== false;
    }

    public function get_signature_plan_age($hubspot_deal_id) {
        $result = $this->wpdb->get_var($this->wpdb->prepare("
            SELECT MAX(date_modification)
            FROM {$this->table_suivi}
            WHERE hubspot_deal_id = %d
            AND slug_phase = 'SignaturePlan'
        ", $hubspot_deal_id));

        if (!$result) {
            return null; // Aucun enregistrement trouvé
        }

        $date_modif = new \DateTime($result);
        $now = new \DateTime();
        $interval = $now->diff($date_modif);

        return $interval->days; // Retourne l'âge en jours
    }





}