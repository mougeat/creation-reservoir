<?php

class ISPAG_Document_Manager {
    private $wpdb;
    private $table_historique;
    private $table_media;
    private $table_projet_articles;
    private $table_achat_articles;

    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->table_historique = $wpdb->prefix . 'achats_historique';
        $this->table_media = $wpdb->prefix . 'posts';
        $this->table_projet_articles = $wpdb->prefix . 'projet_detail';
        $this->table_achat_articles = $wpdb->prefix . 'achats_articles_cmd_fournisseurs';
    }

    public function get_documents_grouped_by_article($deal_id, $is_purchase = false) {
        $sql = "
            SELECT h.*, p.guid AS file_url, p.post_title, p.post_mime_type, u.display_name
            FROM {$this->table_historique} h
            LEFT JOIN {$this->wpdb->users} u ON u.ID = h.IdUser
            LEFT JOIN {$this->table_media} p ON p.ID = h.IdMedia
            WHERE h.hubspot_deal_id = %d AND h.IdMedia > 0
            ORDER BY h.dateReadable DESC
        ";
        $docs = $this->wpdb->get_results($this->wpdb->prepare($sql, $deal_id));
        if (!$docs) return [];

        $grouped = [];

        foreach ($docs as $doc) {
            $is_article = is_numeric($doc->Historique);

            if ($is_article) {
                $article_id = intval($doc->Historique);
                $groupe = $this->get_groupe_from_article($article_id, $is_purchase);
                $key = $groupe ? " $groupe" : "Article $article_id";
            } else {
                $key = __('Other', 'creation-reservoir');
            }

            if (!isset($grouped[$key])) $grouped[$key] = [];
            $grouped[$key][] = $doc;
        }

        return $grouped;
    }

    private function get_groupe_from_article($article_id, $is_purchase = false) {
        if ($is_purchase) {
            $query = "SELECT IdCommandeClient FROM {$this->table_achat_articles} WHERE Id = %d";
        } else {
            $query = "SELECT groupe FROM {$this->table_projet_articles} WHERE id = %d";
        }
        $result = $this->wpdb->get_var($this->wpdb->prepare($query, $article_id));
        return $result ?: null;
    }

    public function render_grouped_documents($grouped_docs) {
        if (empty($grouped_docs)) return '<p>' . __('No documents found', 'creation-reservoir') . '.</p>';

        $html = '';
        foreach ($grouped_docs as $groupe => $docs) {
            $html .= "<h4 class='doc-group-title'>{$groupe}</h4><ul class='ispag-documents-list'>";
            foreach ($docs as $doc) {
                $icon = '📄';
                if (str_contains($doc->post_mime_type, 'pdf')) $icon = '📕';
                elseif (str_contains($doc->post_mime_type, 'image')) $icon = '🖼️';

                $html .= '<li class="document-item">';
                $html .= "<a href='{$doc->file_url}' target='_blank'>{$icon} {$doc->post_title}</a>";
                $html .= "<div class='doc-meta'>Ajouté par {$doc->display_name} le " . date('d.m.Y H:i', strtotime($doc->dateReadable)) . "</div>";
                $html .= '</li>';
            }
            $html .= '</ul>';
        }

        return $html;
    }
}
