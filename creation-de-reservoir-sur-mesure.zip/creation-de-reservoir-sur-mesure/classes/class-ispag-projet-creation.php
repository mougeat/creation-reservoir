<?php

class ISPAG_Projet_Creation {
    private $table;
    private $table_users;
    private $table_clients;

    public function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'achats_liste_commande';
        $this->table_users = $wpdb->prefix . 'users';
        $this->table_clients = $wpdb->prefix . 'achats_fournisseurs';

        add_shortcode('ispag_creation_projet', [$this, 'render_form']);
        add_action('init', [$this, 'handle_form']);

        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
        // add_action('wp_ajax_get_client_by_domain', [$this, 'ajax_get_client_by_domain']);
        // add_action('wp_ajax_nopriv_get_client_by_domain', [$this, 'ajax_get_client_by_domain']);
        add_action('wp_ajax_get_company_by_user_id', [$this, 'ajax_get_company_by_user_id']);
        add_action('wp_ajax_nopriv_get_company_by_user_id', [$this, 'ajax_get_company_by_user_id']);

    }

    public function enqueue_scripts() {
        wp_enqueue_script('jquery');
        wp_enqueue_script('creation-projets-js', plugin_dir_url(__FILE__) . '../assets/js/creation-projets.js', ['jquery'], '1.0', true);

        wp_localize_script('creation-projets-js', 'ispag_ajax_object', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('ispag_nonce')
        ]);
    }

    public function ajax_get_company_by_user_id() {
        check_ajax_referer('ispag_nonce', 'nonce');

        $user_id = intval($_POST['user_id'] ?? 0);
        if (!$user_id) {
            wp_send_json_error('User ID manquant');
        }

        $user = get_userdata($user_id);
        if (!$user) {
            wp_send_json_error('Utilisateur non trouvé');
        }
        $email = $user->user_email;
        $domain = substr(strrchr($email, "@"), 1);
        wp_send_json_success($this->get_client_by_domain($domain));
    }


    private function get_client_by_domain($domain) {
        

        // $domain = sanitize_text_field($_POST['domain'] ?? '');

        if (!$domain) {
            wp_send_json_error('Domaine manquant');
        }

        global $wpdb;
        

        $client = $wpdb->get_row($wpdb->prepare("SELECT Id, Fournisseur FROM $this->table_clients WHERE compagnyDomain = %s", $domain));

        if ($client) {
            wp_send_json_success(['client_name' => $client->Fournisseur, 'client_id' => $client->Id]);
        } else {
            wp_send_json_error('Client non trouvé');
        }
    }

    public function handle_form() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ispag_create_projet'])) {
            $this->save_project();
        }
    }

    private function save_project() {
        global $wpdb;

        $current_user_id = get_current_user_id();
        $timestamp = time();

        $data = [
            'ObjetCommande'        => sanitize_text_field($_POST['ObjetCommande']),
            'AssociatedContactIDs' => intval($_POST['AssociatedContactIDs']),
            'AssociatedCompanyID'  => intval($_POST['AssociatedCompanyID']),
            'Ingenieur'            => sanitize_text_field($_POST['Ingenieur']),
            'EnSoumission'         => sanitize_text_field($_POST['EnSoumission']),
            'hubspot_deal_id'      => $timestamp,
            'TimestampDateCommande'=> $timestamp,
            'created_by'           => $current_user_id,
            'isQotation'           => isset($_POST['isQotation']) ? 1 : 0,
            'CmdActif'             => 1,
            'Abonne'               => ';0;'.$current_user_id.';',
        ];

        if (!$data['isQotation']) {
            $data['NumCommande'] = sanitize_text_field($_POST['NumCommande']);
            $data['customer_order_id'] = sanitize_text_field($_POST['customer_order_id']);
        }

        $inserted = $wpdb->insert($this->table, $data);
        if ($inserted === false) {
            // gestion d’erreur ici, si besoin
            add_action('admin_notices', function() {
                echo '<div class="error"><p>Erreur lors de l\'enregistrement du projet.</p></div>';
            });
        } else {
            // stocker un message de succès dans une session ou option temporaire
            // pour l’afficher dans le formulaire (simplification ici)
            $_SESSION['ispag_message'] = 'Projet enregistré avec succès !';
        }

        // redirection pour éviter re-soumission
        wp_redirect(add_query_arg('ispag_created', '1', $_SERVER['REQUEST_URI']));
        exit;
    }

    public function render_form($atts) {
        if (!session_id()) session_start();

        $atts = shortcode_atts([
            'qotation' => null
        ], $atts);

        // Convertit l'attribut en booléen
        $is_qotation = ($atts['qotation'] === '1');


        global $wpdb;
        $current_user_id = get_current_user_id();
        $current_user = get_userdata($current_user_id);
        $message = '';

        if (!empty($_SESSION['ispag_message'])) {
            $message = $_SESSION['ispag_message'];
            unset($_SESSION['ispag_message']);
        } elseif (isset($_GET['ispag_created'])) {
            $message = __('Project created succesfully', 'creation-reservoir') .' !';
        }

        // Contacts
        if (current_user_can('manage_order')) {
            // Affiche toute la liste
            $users = $wpdb->get_results("SELECT ID, display_name FROM {$this->table_users} ORDER BY display_name");
        } else {
            // Que l'utilisateur actuel
            $users = [$current_user];
        }

        // Clients
        if (current_user_can('manage_order')) {
            $clients = $wpdb->get_results("SELECT Id, Fournisseur FROM {$this->table_clients} ORDER BY Fournisseur");
        } else {
            // Récupérer domaine email utilisateur
            $email = $current_user->user_email;
            $domain = substr(strrchr($email, "@"), 1);

            $clients = $wpdb->get_results($wpdb->prepare(
                "SELECT Id, Fournisseur FROM {$this->table_clients} WHERE companyDomain = %s",
                $domain
            ));
        }

        // Récupération ingénieurs et soumissions
        $ingenieurs = $wpdb->get_col("SELECT DISTINCT Ingenieur FROM {$this->table} WHERE Ingenieur IS NOT NULL");
        $soumissions = $wpdb->get_col("SELECT DISTINCT EnSoumission FROM {$this->table} WHERE EnSoumission IS NOT NULL");

        ob_start(); ?>
        
        <form method="post" style="max-width:500px; margin:auto; font-family:sans-serif;">
            <h3 style="text-align:center;"><?php echo __('New project', 'creation-reservoir'); ?></h3>
            <?php if ($message): ?>
                <p style="color:green; font-weight:bold; text-align:center;"><?= esc_html($message) ?></p>
            <?php endif; ?>

            <label><?php echo __('Project name', 'creation-reservoir'); ?></label><br>
            <input type="text" name="ObjetCommande" required style="width:100%; padding:8px; margin-bottom:15px;"><br>

            <label><?php echo __('Contact', 'creation-reservoir'); ?></label><br>
            <select name="AssociatedContactIDs" id="AssociatedContactIDs" required style="width:100%; padding:8px; margin-bottom:15px;">
                <option value="">-- <?php echo __('Select', 'creation-reservoir'); ?> --</option>
                <?php foreach ($users as $user): ?>
                    <option value="<?= esc_attr($user->ID) ?>" <?= ($user->ID == $current_user_id) ? 'selected' : '' ?>>
                        <?= esc_html($user->display_name) ?>
                    </option>
                <?php endforeach; ?>
            </select><br>

            <label><?php echo __('Company', 'creation-reservoir'); ?></label><br>
            <select name="AssociatedCompanyID" required style="width:100%; padding:8px; margin-bottom:15px;">
                <option value="">-- <?php echo __('Select', 'creation-reservoir'); ?> --</option>
                <?php foreach ($clients as $client): ?>
                    <option value="<?= esc_attr($client->Id) ?>"><?= esc_html($client->Fournisseur) ?></option>
                <?php endforeach; ?>
            </select><br>

            <label><?php echo __('Ingenieur', 'creation-reservoir'); ?></label><br>
            <input list="ingenieurs" name="Ingenieur" style="width:100%; padding:8px; margin-bottom:15px;">
            <datalist id="ingenieurs">
                <?php foreach ($ingenieurs as $eng): ?>
                    <option value="<?= esc_attr($eng) ?>">
                <?php endforeach; ?>
            </datalist><br>

            <label><?php echo __('In submission', 'creation-reservoir'); ?></label><br>
            <input list="soumissions" name="EnSoumission" style="width:100%; padding:8px; margin-bottom:15px;">
            <datalist id="soumissions">
                <?php foreach ($soumissions as $sou): ?>
                    <option value="<?= esc_attr($sou) ?>">
                <?php endforeach; ?>
            </datalist><br>
            <?php
            $checked = $is_qotation ? 'checked' : '';
            $html = '<input type="checkbox" name="isQotation" id="isQotation" onchange="toggleCommande()" ' . $checked . '> ';
            ?>
            <label> <?php echo $html . __('Is submission', 'creation-reservoir'); ?></label><br><br>

            <div id="commandeFields">
                <label><?php echo __('Project nb', 'creation-reservoir'); ?></label><br>
                <input type="text" name="NumCommande" style="width:100%; padding:8px; margin-bottom:15px;"><br>

                <label><?php echo __('Order nb', 'creation-reservoir'); ?></label><br>
                <input type="text" name="customer_order_id" style="width:100%; padding:8px; margin-bottom:15px;"><br>
            </div>

            <button type="submit" name="ispag_create_projet" style="background:#0073aa; color:#fff; border:none; padding:10px 20px; cursor:pointer; width:100%;"><?php echo __('Save', 'creation-reservoir'); ?></button>
        </form>

        <script>
            function toggleCommande() {
                const isQuote = document.getElementById('isQotation').checked;
                document.getElementById('commandeFields').style.display = isQuote ? 'none' : 'block';
            }
            toggleCommande();
        </script>

        <?php
        return ob_get_clean();
    }

}
