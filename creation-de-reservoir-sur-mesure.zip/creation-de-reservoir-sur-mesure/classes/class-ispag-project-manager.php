<?php
defined('ABSPATH') or die();

class ISPAG_Project_Manager {

    public static function init() {
        add_shortcode('ispag_projets', [self::class, 'shortcode_projets']);
        add_action('wp_enqueue_scripts', [self::class, 'enqueue_assets']);
    }

    public static function enqueue_assets() {
        wp_enqueue_style('ispag-style', plugin_dir_url(__FILE__) . '../assets/css/style.css');

        wp_enqueue_script('ispag-scroll', plugin_dir_url(__FILE__) . '../assets/js/infinite-scroll.js', [], false, true);
        wp_localize_script('ispag-scroll', 'ajaxurl', admin_url('admin-ajax.php'));
    }

    public static function shortcode_projets($atts) {
        $atts = shortcode_atts([
            'actif' => null,
            'qotation' => null,
        ], $atts);

        $qotation = ($atts['qotation'] === '1') || (isset($_GET['qotation']) && $_GET['qotation'] == 1);
        $search_query = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : null;

        


        $html = '<form method="get" style="margin-bottom: 20px;">
            <input type="text" name="search" placeholder="Rechercher un projet, contact ou entreprise" value="' . esc_attr($search_query) . '" style="width: 300px; padding: 5px;" />
            <input type="hidden" name="qotation" value="' . ($qotation ? '1' : '0') . '" />
            <button type="submit">Rechercher</button>
        </form>';

        $html .= '<div id="projets-meta" data-qotation="' . esc_attr($qotation) . '" data-search="' . esc_attr($search_query) . '"></div>';

        $html .= '<div class="ispag-table-wrapper">';
        $html .= '<table class="ispag-project-table">';
        $html .= '<thead><tr>';
        $html .= '<th></th><th>Nom projet</th><th>Prix total</th><th>Étape</th>';
        if (!$qotation) {
            $html .= '<th>Livraison</th><th>Soudure</th><th>Isolation</th>';
        }
        $html .= '<th>Contact</th><th>Entreprise</th>';
        $html .= '</tr></thead>';
        $html .= '<tbody id="projets-list"></tbody>';
        $html .= '</table>';
        $html .= '</div>';
        $html .= '<div id="scroll-loader" style="height: 40px;"></div>';

        return $html;
    }

    // public static function shortcode_projets($atts) {
    //     $atts = shortcode_atts([
    //         'actif' => null,
    //         'qotation' => null,
    //     ], $atts);

    //     $qotation = ($atts['qotation'] === '1') || (isset($_GET['qotation']) && $_GET['qotation'] == 1);
    //     $search_query = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : null;

    //     $current_user_id = get_current_user_id();
    //     $can_view_all = current_user_can('real_all_orders');
    //     $can_view_own = current_user_can('read_orders');

    //     $projetRepo = new ISPAG_Projet_Repository(true);

    //     // 🔍 Filtrage par recherche
        

    //     if ($can_view_all) {
    //         $projects = $projetRepo->get_projects_or_offers($qotation, null, true, $search_query);
    //     } elseif ($can_view_own) {
    //         $projects = $projetRepo->get_projects_or_offers($qotation, $current_user_id, false, $search_query);
    //     } else {
    //         return '<p>' . __('Vous n\'avez pas les droits pour voir cette page.', 'creation-reservoir') . '</p>';
    //     }

    //     // 🔍 Filtrage actif
    //     if ($atts['actif'] == '1') {
    //         $projects = array_filter($projects, fn($p) => $p->CmdActif == 1);
    //     }

    //     // // 🔍 Filtrage par recherche
    //     // if ($search_query) {
    //     //     $projects = array_filter($projects, function ($p) use ($search_query) {
    //     //         $search = strtolower($search_query);
    //     //         return str_contains(strtolower($p->ObjetCommande), $search)
    //     //             || str_contains(strtolower($p->contact_name), $search)
    //     //             || str_contains(strtolower($p->nom_entreprise), $search);
    //     //     });
    //     // }

    //     // 🔎 Formulaire de recherche au-dessus du tableau
    //     $html = '<form method="get" style="margin-bottom: 20px;">
    //         <input type="text" name="search" placeholder="Rechercher un projet, contact ou entreprise" value="' . esc_attr($search_query) . '" style="width: 300px; padding: 5px;" />
    //         <input type="hidden" name="qotation" value="' . ($qotation ? '1' : '0') . '" />
    //         <button type="submit">Rechercher</button>
    //     </form>';

    //     // $html .= self::render_table($projects, $qotation);

    //     $html .= '<div id="projets-list"></div>
    //       <div id="scroll-loader" style="height: 40px;"></div>';

    //     return $html;
    // }

    public static function render_project_row($p, $is_quotation, $show_price, $i) {
        $bgcolor = !empty($p->next_phase->Color) ? esc_attr($p->next_phase->Color) : '#ccc';
        $row_class = ($i % 2 === 1) ? ' style="background-color:#f0f0f0;"' : '';

        $html = '<tr' . $row_class . '>';
        $html .= '<td style="background-color:#b8e994;"></td>';
        $html .= '<td><a href="' . esc_url($p->project_url) . '" target="_blank">' . esc_html($p->ObjetCommande) . '</a></td>';
        $html .= '<td>' . ($show_price ? number_format($p->prix_net, 2, ',', ' ') . ' CHF' : '&mdash;') . '</td>';
        $html .= '<td><span class="badge" style="background-color:' . $bgcolor . '; opacity: 0.5;">' . esc_html__($p->next_phase->TitrePhase, 'creation-reservoir') . '</span></td>';

        if (!$is_quotation) {
            $html .= '<td>' . $p->bar_product . '</td>';
            $html .= '<td>' . $p->bar_welding . '</td>';
            $html .= '<td>' . $p->bar_isol . '</td>';
        }

        $html .= '<td>' . esc_html($p->contact_name) . '</td>';
        $html .= '<td>' . esc_html($p->nom_entreprise) . '</td>';
        $html .= '</tr>';

        return $html;
    }





    // Méthode de rendu du tableau
    public static function render_table($projects, $is_quotation) {
        if (empty($projects)) {
            return '<p>' . __('Aucun projet ou offre trouvé.', 'creation-reservoir') . '</p>';
        }

        $current_user = wp_get_current_user();
        $show_price = current_user_can('real_all_orders') || in_array('administrator', $current_user->roles);

        $output = '<div class="ispag-table-wrapper">';
        $output .= '<table class="ispag-project-table">';
        $output .= '<thead><tr>';
        $output .= '<th></th>';
        $output .= '<th>' . __('Project name', 'creation-reservoir') . '</th>';
        $output .= '<th>' . __('Total price', 'creation-reservoir') . '</th>';
        $output .= '<th>' . __('States', 'creation-reservoir') . '</th>';
        

        if (!$is_quotation) {
            $output .= '<th>' . __('Tank delivery date', 'creation-reservoir') . '</th>';
            $output .= '<th>' . __('Welding date', 'creation-reservoir') . '</th>';
            $output .= '<th>' . __('Insulation date', 'creation-reservoir') . '</th>';
        }

        $output .= '<th>' . __('Contact', 'creation-reservoir') . '</th>';
        $output .= '<th>' . __('Company', 'creation-reservoir') . '</th>';
        $output .= '</tr></thead><tbody>';

        // $projetSuivi = new ISPAG_Projet_Suivi();
        $i = 0;
        foreach ($projects as $p) {
            
            $bgcolor = !empty($p->next_phase->Color) ? esc_attr($p->next_phase->Color) : '#ccc'; // gris clair par défaut
            $row_class = ($i % 2 === 1) ? ' style="background-color:#f0f0f0;"' : '';
            $output .= '<tr' . $row_class . '>';
            $output .= '<td style="background-color:#b8e994;"></td>';
            $output .= '<td><a href="' . $p->project_url . '" target="_blank" rel="noopener noreferrer">' . esc_html($p->ObjetCommande) . '</a></td>';

            if ($show_price) {
                $output .= '<td>' . number_format($p->prix_net, 2, ',', ' ') . ' CHF</td>';
            } else {
                $output .= '<td>&mdash;</td>';
            }

            
            $text = __(esc_html($p->next_phase->TitrePhase),"creation-reservoir");
            $badge = "<span  class=\"badge bg-{$bgcolor} text-dark\" style=\"--bs-bg-opacity: 0.5; padding: 3px 6px; font-size: 0.8rem;\">{$text}</span>";
            // $badge = '&mdash;';
            $output .= '<td>' . $badge . '</td>';
            

            if (!$is_quotation) {
                
                $output .= '<td>' . $p->bar_product . '</td>';
                $output .= '<td>' . $p->bar_welding . '</td>';
                $output .= '<td>' . $p->bar_isol . '</td>';
            }

            $output .= '<td>' . esc_html($p->contact_name) . '</td>';
            $output .= '<td>' . esc_html($p->nom_entreprise) . '</td>';
            $output .= '</tr>';

            $i++;
        }

        $output .= '</tbody></table>';
        $output .= '</div>';


        return $output;
    }

}


add_action('wp_ajax_ispag_load_more_projects', 'ispag_load_more_projects');
add_action('wp_ajax_nopriv_ispag_load_more_projects', 'ispag_load_more_projects');

function ispag_load_more_projects() {
    $offset = intval($_POST['offset']);
    $limit = 20;

    $qotation = $_POST['qotation'] == '1';
    $search_query = sanitize_text_field($_POST['search']);
    $current_user_id = get_current_user_id();

    $can_view_all = current_user_can('real_all_orders');
    $can_view_own = current_user_can('read_orders');

    $repo = new ISPAG_Projet_Repository(true);
    $all_projects = [];

    if ($can_view_all) {
        $all_projects = $repo->get_projects_or_offers($qotation, null, true, $search_query);
    } elseif ($can_view_own) {
        $all_projects = $repo->get_projects_or_offers($qotation, $current_user_id, false, $search_query);
    }

    $paged_projects = array_slice($all_projects, $offset, $limit);
    $html = '';

    $current_user = wp_get_current_user();
    $show_price = $can_view_all || in_array('administrator', $current_user->roles);

    foreach ($paged_projects as $i => $p) {
        $html .= ISPAG_Project_Manager::render_project_row($p, $qotation, $show_price, $offset + $i);
    }

    wp_send_json_success(['html' => $html, 'has_more' => count($paged_projects) === $limit]);
}
