<?php
defined('ABSPATH') or die();

class ISPAG_Article_Repository {
    protected $wpdb;
    protected $table_articles;
    protected $table_prestations;

    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->table_articles = $wpdb->prefix . 'achats_details_commande';
        $this->table_prestations = $wpdb->prefix . 'achats_type_prestations';
    }

    public function get_articles_by_deal($deal_id) {
        if (empty($deal_id) || !is_numeric($deal_id)) {
            error_log("ISPAG_Article_Repository: deal_id incorrect");
            return [];
        }

        $sql = "
            SELECT 
                a.*,
                p.sort AS prestation_sort,
                p.prestation
            FROM {$this->table_articles} a
            LEFT JOIN {$this->table_prestations} p ON p.type = a.Type
            WHERE a.hubspot_deal_id = %d
            ORDER BY a.Groupe ASC, p.sort ASC, a.tri ASC
        ";

        $prepared_sql = $this->wpdb->prepare($sql, $deal_id);
        if ($prepared_sql === false) {
            error_log("ISPAG_Article_Repository: erreur prepare SQL");
            return [];
        }

        $results = $this->wpdb->get_results($prepared_sql);

        if ($results === null) {
            error_log("ISPAG_Article_Repository: erreur get_results SQL");
            return [];
        }

        if (empty($results)) return [];

        // Regroupement
        $grouped = [];
        $principaux = [];

        foreach ($results as $article) {
            if ($article->IdArticleMaster == 0) {
                $article->secondaires = [];
                $principaux[$article->Id] = $article;
            }
        }

        foreach ($results as $article) {
            if ($article->IdArticleMaster != 0 && isset($principaux[$article->IdArticleMaster])) {
                $principaux[$article->IdArticleMaster]->secondaires[] = $article;
            }
        }

        foreach ($principaux as $principal) {
            $grouped[$principal->Groupe][] = $principal;
        }

        return $grouped;
    }
}
