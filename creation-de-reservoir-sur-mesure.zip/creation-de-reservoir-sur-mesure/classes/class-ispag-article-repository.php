<?php
defined('ABSPATH') or die();

class ISPAG_Article_Repository {
    protected $wpdb;
    protected $table_articles;
    protected $table_prestations;
    protected $table_fournisseurs;
    protected $table_article;
    protected $table_article_purchase;

    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->table_articles = $wpdb->prefix . 'achats_details_commande';
        $this->table_prestations = $wpdb->prefix . 'achats_type_prestations';
        $this->table_fournisseurs = $wpdb->prefix . 'achats_fournisseurs';
        $this->table_article = $wpdb->prefix . 'achats_articles';
        $this->table_article_purchase = $wpdb->prefix . 'achats_articles_purchase';
    }

    public function get_articles_by_deal($deal_id) {
        if (empty($deal_id) || !is_numeric($deal_id)) {
            error_log("ISPAG_Article_Repository: deal_id incorrect");
            return [];
        }

        

        $sql = "
            SELECT 
                a.*,
                p.sort AS prestation_sort,
                p.prestation,
                f.Fournisseur AS fournisseur_nom
            FROM {$this->table_articles} a
            LEFT JOIN {$this->table_prestations} p ON p.type = a.Type
            LEFT JOIN {$this->table_fournisseurs} f ON f.Id = a.IdFournisseur
            WHERE a.hubspot_deal_id = %d
            ORDER BY a.Groupe ASC, p.sort ASC, a.tri ASC
        ";

        $prepared_sql = $this->wpdb->prepare($sql, $deal_id);
        if ($prepared_sql === false) {
            error_log("ISPAG_Article_Repository: erreur prepare SQL");
            return [];
        }

        $results = $this->wpdb->get_results($prepared_sql);

        if ($results === null) {
            error_log("ISPAG_Article_Repository: erreur get_results SQL");
            return [];
        }

        if (empty($results)) return [];

        // Regroupement
        $grouped = [];
        $principaux = [];

        foreach ($results as $article) {
            if ($article->IdArticleMaster == 0) {
                $article->secondaires = [];
                $principaux[$article->Id] = $article;
            }
        }

        foreach ($results as $article) {
            if ($article->IdArticleMaster != 0 && isset($principaux[$article->IdArticleMaster])) {
                $principaux[$article->IdArticleMaster]->secondaires[] = $article;
            }
        }

        // foreach ($principaux as $principal) {
        //     $grouped[$principal->Groupe][] = $principal;
        // }

        foreach ($principaux as $principal) {
            $prix_total = floatval($principal->sales_price) * intval($principal->Qty);

            foreach ($principal->secondaires as $secondaire) {
                $prix_total += floatval($secondaire->sales_price) * intval($secondaire->Qty);
            }

            $principal->prix_total_calculé = $prix_total;
            $grouped[$principal->Groupe][] = $principal;
        }


        return $grouped;
    }



    public function get_article_by_id($id) {
        $sql = "
            SELECT 
                a.*,
                p.sort AS prestation_sort,
                p.prestation,
                f.Fournisseur AS fournisseur_nom
            FROM {$this->table_articles} a
            LEFT JOIN {$this->table_prestations} p ON p.type = a.Type
            LEFT JOIN {$this->table_fournisseurs} f ON f.Id = a.IdFournisseur
            WHERE a.Id = %d
            ORDER BY a.Groupe ASC, p.sort ASC, a.tri ASC
        ";

       $prepared_sql = $this->wpdb->prepare($sql, $id);
       $article = $this->wpdb->get_row($prepared_sql);

        if ($article && isset($article->hubspot_deal_id)) {
            $article->master_articles = $this->get_article_and_group($article->hubspot_deal_id);
        } else {
            $article->master_articles = [];
        }

        return $article;
    }
    public function get_article_and_group($deal_id = null) {
        $articles_groupes = $this->wpdb->get_results(
            $this->wpdb->prepare("
                SELECT Id, Article, Groupe
                FROM {$this->table_articles}
                WHERE IdArticleMaster = 0 AND hubspot_deal_id = %d
                ORDER BY Groupe ASC, tri ASC
            ", $deal_id)
        );
        $articles_grouped = [];

        foreach ($articles_groupes as $art) {
            $groupe = $art->Groupe ?: 'Autre';
            if (!isset($articles_grouped[$groupe])) {
                $articles_grouped[$groupe] = [];
            }
            $articles_grouped[$groupe][] = $art;
        }

        return $articles_grouped;
    }
    public function get_groupes_by_deal($deal_id) {
        $sql = "
            SELECT DISTINCT Groupe
            FROM {$this->table_articles}
            WHERE hubspot_deal_id = %d AND Groupe IS NOT NULL AND Groupe != ''
            ORDER BY Groupe ASC
        ";

        return $this->wpdb->get_col($this->wpdb->prepare($sql, $deal_id));
    }

    public function get_standard_titles_by_type($type) {
        $table_standard = $this->wpdb->prefix . 'achats_articles';

        $results = $this->wpdb->get_col(
            $this->wpdb->prepare("SELECT DISTINCT TitreArticle FROM $table_standard WHERE TypeArticle = %d ORDER BY TitreArticle ASC", $type)
        );

        return $results ?: [];
    }
    public function get_standard_article_by_title($title, $type) {
        $sql = $this->wpdb->prepare("
            SELECT a.TitreArticle, a.description_ispag, a.sales_price, f.Fournisseur
            FROM {$this->table_article} a
            LEFT JOIN {$this->table_article_purchase} ap ON ap.article_id = a.Id
            LEFT JOIN {$this->table_fournisseurs} f ON f.Id = ap.supplier_id
            WHERE a.TitreArticle = %s AND a.TypeArticle = %d
        ", $title, $type);

        $results = $this->wpdb->get_results($sql);
        if (empty($results)) {
            return null;
        }

        // On prend les infos générales depuis la première ligne
        $article_info = (object) [
            'TitreArticle' => $results[0]->TitreArticle,
            'description_ispag' => html_entity_decode($results[0]->description_ispag),
            'sales_price' => $results[0]->sales_price,
            'suppliers' => [],
        ];

        // On récupère tous les fournisseurs uniques
        $suppliers = [];
        foreach ($results as $row) {
            if ($row->Fournisseur && !in_array($row->Fournisseur, $suppliers)) {
                $suppliers[] = $row->Fournisseur;
            }
        }
        $article_info->suppliers = $suppliers;

        return $article_info;
    }



}
