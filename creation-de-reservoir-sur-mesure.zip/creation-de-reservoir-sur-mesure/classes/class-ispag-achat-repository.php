<?php

class ISPAG_Achat_Repository {
    private $wpdb;
    private $table_achats;
    private $table_articles;
    private $table_fournisseurs;
    private $table_etat;

    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->table_achats = $wpdb->prefix . 'achats_commande_liste_fournisseurs';
        $this->table_articles = $wpdb->prefix . 'achats_articles_cmd_fournisseurs';
        $this->table_fournisseurs = $wpdb->prefix . 'achats_fournisseurs';
        $this->table_etat = $wpdb->prefix . 'achats_etat_commandes_fournisseur';
    }

    public function get_achats($user_id = null, $all = false, $search = '', $offset = 0, $limit = 15) {
        $query = "
            SELECT a.*, f.Fournisseur, ar.TimestampDateLivraisonConfirme, e.Etat, e.ClassCss, e.color
            FROM {$this->table_achats} a
            LEFT JOIN {$this->table_articles} ar ON ar.IdCommande = a.Id
            LEFT JOIN {$this->table_fournisseurs} f ON f.Id = a.IdFournisseur
            LEFT JOIN {$this->table_etat} e ON e.Id = a.EtatCommande
            WHERE 1 = 1
        ";

        $query_params = [];

        if (!$all && $user_id) {
            $query .= " AND a.Abonne LIKE %s";
            $query_params[] = '%;' . $user_id . ';%';
        }

        if (!empty($search)) {
            $query .= " AND (a.RefCommande LIKE %s OR f.Fournisseur LIKE %s OR a.ConfCmdFournisseur LIKE %s OR a.NrCommande LIKE %d)";
            $like = '%' . $search . '%';
            $query_params[] = $like;
            $query_params[] = $like;
            $query_params[] = $like;
            $query_params[] = $like;
        } else {
            $query .= " AND a.TimestampDateCreation > UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 6 MONTH))";
        }

        $query .= " GROUP BY a.Id ORDER BY a.TimestampDateCreation DESC LIMIT %d OFFSET %d";
        $query_params[] = $limit;
        $query_params[] = $offset;

        $prepared = $this->wpdb->prepare($query, ...$query_params);
        $results = $this->wpdb->get_results($prepared);

        if (!$results) {
            return [];
        }

        // 3. Compléter les projets
        $base_url = trailingslashit(get_site_url()) . 'liste-des-projets/';
        foreach ($results as $p) {
            $p->project_url = esc_url(add_query_arg('poid', $p->Id, $base_url));
        }
        return $results;
    }
}
