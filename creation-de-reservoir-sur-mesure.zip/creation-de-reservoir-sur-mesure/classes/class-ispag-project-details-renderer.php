<?php 

class ISPAG_Project_Details_Renderer {

    public static function display($deal_id) {
        $project_repo = new ISPAG_Projet_Repository();
        $details_repo = new ISPAG_Project_Details_Repository(); 

        $project = $project_repo->get_projects_or_offers('','', '', $deal_id);
        $infos = $details_repo->get_infos_livraison($deal_id);

        // echo '<pre>';
        // var_dump($project);
        // echo '</pre>';

        echo '<div class="ispag-detail-section">';
        self::render_bloc_project_info($project);
        self::render_bloc_livraison($infos, $project);
        if (current_user_can('manage_order')) self::render_bloc_soumission($project);
        echo '</div>';
    }

    private static function render_bloc_project_info($project) {
        $p = $project[0]; // raccourci
        $deal_id = (int) $p->hubspot_deal_id;
        $can_edit = current_user_can('manage_order') ;

        echo '<div class="ispag-box">';
        echo '<h3>' . __('Project informations', 'creation-reservoir') . '</h3>';

        echo '<p><strong>Status :</strong> ' . esc_html($p->next_phase->TitrePhase ?? 'Non défini') . '</p>';

        // Champs modifiables avec leurs libellés
        $champs = [
            'NumCommande'        => __('Order number', 'creation-reservoir'),
            'customer_order_id'  => __('Customer order ID', 'creation-reservoir'),
        ];

        foreach ($champs as $champ => $label) {
            $val = $p->$champ ?? '';
            echo '<p><strong>' . esc_html($label) . ' :</strong> ';
            if ($can_edit) {
                echo '<span class="ispag-inline-edit" 
                            data-name="' . esc_attr($champ) . '" 
                            data-value="' . esc_attr($val) . '" 
                            data-deal="' . esc_attr($deal_id) . '"
                            data-source="project">';
                echo esc_html($val) . ' <span class="edit-icon">✏️</span>';
                echo '</span>';
            } else {
                echo esc_html($val);
            }
            echo '</p>';
        }

        // Champs non éditables
        echo '<p><strong>' . __('Date', 'creation-reservoir') . ' :</strong> ' . date('d.m.Y', $p->TimestampDateCommande) . '</p>';
        echo '<p><strong>' . __('Contact', 'creation-reservoir') . ' :</strong> ' . esc_html($p->contact_name) . '</p>';
        echo '<p><strong>' . __('Company', 'creation-reservoir') . ' :</strong> ' . esc_html($p->nom_entreprise) . '</p>';

        echo '</div>';
    }


    private static function render_bloc_livraison($infos, $project) {
        echo '<div class="ispag-box">';
        echo '<h3>' . __('Delivery', 'creation-reservoir') . '</h3>';

        // Liste des champs affichés + nom lisible
        $champs = [
            'AdresseDeLivraison' => __('Adress', 'creation-reservoir'),
            'DeliveryAdresse2'   => __('Complement', 'creation-reservoir'),
            'City'               => __('City', 'creation-reservoir'),
            'PersonneContact'    => __('Contact', 'creation-reservoir'),
            'num_tel_contact'    => __('Phone', 'creation-reservoir'),
        ];
            
        foreach ($champs as $champ => $label) {
            
            $val = $infos->$champ ?? '';
            echo '<p><strong>' . esc_html($label) . ' :</strong> ';
            
            if (current_user_can('manage_order') || ISPAG_Projet_Repository::is_user_project_owner($infos->hubspot_deal_id)) {
                echo '<span class="ispag-inline-edit" 
                            data-name="' . esc_attr($champ) . '" 
                            data-value="' . esc_attr($val) . '" 
                            data-deal="' . esc_attr($infos->hubspot_deal_id) . '"
                            data-source="delivery">';
                echo esc_html($val) . ' <span class="edit-icon">✏️</span>';
                echo '</span>';
            } else {
                echo esc_html($val);
            }

            echo '</p>';
        }

        echo '</div>';
    }


    private static function render_bloc_soumission($project) {
        $p = $project[0]; // raccourci
        $deal_id = (int) $p->hubspot_deal_id;
        echo '<div class="ispag-box">';
        echo '<h3>' . __('Submission information', 'creation-reservoir') . '</h3>';

        $champs = [
            'Ingenieur'     => __('Engineer', 'creation-reservoir'),
            'EnSoumission'  => __('Competitor', 'creation-reservoir'),
        ];

        foreach ($champs as $champ => $label) {
            $val = $p->$champ ?? ''; // ✅ correction ici

            echo '<p><strong>' . esc_html($label) . ' :</strong> ';

            if (current_user_can('manage_order')) {
                echo '<span class="ispag-inline-edit" 
                            data-name="' . esc_attr($champ) . '" 
                            data-value="' . esc_attr($val) . '" 
                            data-deal="' . esc_attr($deal_id) . '"
                            data-source="project">';
                echo esc_html($val) . ' <span class="edit-icon">✏️</span>';
                echo '</span>';
            } else {
                echo esc_html($val ?: '-');
            }

            echo '</p>';
        }

        echo '</div>';
    }


}
