<?php
defined('ABSPATH') or die();

class ISPAG_Detail_Page {
    public static function init() {
        add_shortcode('ispag_detail', [self::class, 'render']);
        add_action('wp_enqueue_scripts', [self::class, 'enqueue_assets']);
    }

    public static function enqueue_assets() {
        wp_enqueue_style('ispag-detail-style', plugin_dir_url(__FILE__) . '../assets/css/detail.css');
        wp_enqueue_script('ispag-detail-tabs', plugin_dir_url(__FILE__) . '../assets/js/tabs.js', [], false, true);
        wp_enqueue_script('ispag-detail-suivi', plugin_dir_url(__FILE__) . '../assets/js/suivi.js', [], false, true);
        wp_enqueue_script('ispag-detail-display', plugin_dir_url(__FILE__) . '../assets/js/details.js', [], false, true);

        $statuses = (new ISPAG_Projet_Suivi())->get_all_statuses();
        wp_localize_script('ispag-detail-tabs', 'ispagStatusChoices', $statuses);

        wp_localize_script('ispag-detail-display', 'ispag_texts', [
            'confirm_delete_article' => __('Delete this item', 'creation-reservoir')
        ]);
        

    }

    public static function render($atts) {
        $deal_id = isset($_GET['deal_id']) ? sanitize_text_field($_GET['deal_id']) : '';
        $isQotation = isset($_GET['qotation']) && isset($_GET['qotation']) == 1;
        if (!$deal_id) return '<p>Projet introuvable.</p>';

        $project_detail = new ISPAG_Projet_Repository();
        $details = $project_detail->get_projects_or_offers($isQotation, null, true, $deal_id);

        $can_manage_order = current_user_can('manage_order'); // corrige la capacité ici


        $title = 'Détail du projet : ' . esc_html($details[0]->ObjetCommande); // on améliorera avec le vrai nom

        ob_start();
        ?>
        <h2><?php echo $title; ?></h2>
        <div class="ispag-tabs">
            <ul class="tab-titles">
                <li class="active" data-tab="postes"><?php echo __('Articles', 'creation-reservoir'); ?></li>
                <li data-tab="notes"><?php echo __('Notes', 'creation-reservoir'); ?></li>
                <li data-tab="details"><?php echo __('Details', 'creation-reservoir'); ?></li>
                <li data-tab="suivi"><?php echo __('Follow up', 'creation-reservoir'); ?></li>
                <li data-tab="docs"><?php echo __('Document flow', 'creation-reservoir'); ?></li>
                <?php if ($can_manage_order){ ?>
                <li data-tab="log"><?php echo __('Logs', 'creation-reservoir'); ?></li>
                <?php } ?>
            </ul>
            <div class="tab-content active" id="postes"><?php display_ispag_project_articles($deal_id); ?></div>
            <div class="tab-content" id="notes">Notes ici</div>
            <div class="tab-content" id="details"><?php display_ispag_project_details($deal_id); ?></div>
            <div class="tab-content" id="suivi">
                <?php display_ispag_suivis($deal_id, $isQotation); ?>
            </div>
            <div class="tab-content" id="docs">
                <?php display_ispag_doc_manger($deal_id); ?>
                    
            </div>
            <div class="tab-content" id="log">Log ici</div>
        </div>
        <?php
        echo "<script>document.title = '" . esc_js($title) . "';</script>";
        echo self::display_modal();
        return ob_get_clean();
    }


    
    public static function render_articles_list($grouped_articles) {
        echo '<div class="ispag-articles-list">';

        foreach ($grouped_articles as $groupe => $articles_principaux) {
            $escaped_group = esc_html($groupe);
            $id = 'group-title-' . md5($groupe); // ID unique pour JS

            echo '<div class="ispag-article-group-header">';
            echo '<h3 id="' . esc_attr($id) . '">' . $escaped_group . '</h3>';
            echo '<button class="ispag-btn-copy-group" data-target="' . esc_attr($id) . '">📋</button>';
            echo '</div>';

            foreach ($articles_principaux as $article) {
                self::render_article_block($article);

                if (current_user_can('manage_order') && !empty($article->secondaires)) {
                    foreach ($article->secondaires as $secondaire) {
                        self::render_article_block($secondaire, true);
                    }
                }
            }
        }

        echo '</div>';
        

        // JS pour copier dans le presse-papier
        ?>
        <script>
        document.querySelectorAll('.ispag-btn-copy-group').forEach(btn => {
            btn.addEventListener('click', () => {
                const targetId = btn.getAttribute('data-target');
                const text = document.getElementById(targetId)?.innerText;
                if (text) {
                    navigator.clipboard.writeText(text).then(() => {
                        btn.innerText = '✅';
                        setTimeout(() => btn.innerText = '📋', 1000);
                    });
                }
            });
        });
        </script>
        <?php
    }
    private static function display_modal(){
        return '<div id="ispag-modal" class="ispag-modal" style="display:none;">
            <div class="ispag-modal-content">
                <span class="ispag-modal-close">&times;</span>
                <div id="ispag-modal-body">
                    <!-- Le contenu sera injecté ici en JS -->
                </div>
            </div>
        </div>';

    }

    public static function render_article_block($article, $is_secondary = false) {
        $id = (int) $article->Id;
        $checked_attr = ''; // checkbox à cocher en JS si besoin
        $titre = esc_html($article->Article);
        $status = $article->Livre ? 'Livré' : 'En attente de signature';
        $facture = $article->invoiced ? 'Facturé' : 'Non facturé';
        $qty = (int) $article->Qty;
        $prix_brut = number_format((float) $article->prix_total_calculé, 2, '.', ' ');
        $rabais = number_format((float) $article->discount, 2, '.', ' ');
        $prix_net = number_format($qty * $article->sales_price * (1 - $article->discount/100), 2, '.', ' ');
        $user_can_manage_order = current_user_can('manage_order');

        $class_secondary = $is_secondary ? ' ispag-article-secondary' : '';
        
        echo '<div class="ispag-article' . $class_secondary . '" data-article-id="' . $id . '" data-level-secondary="' . $class_secondary . '" >';
        
        // Checkbox
        echo '<input type="checkbox" class="ispag-article-checkbox" data-article-id="' . $id . '" ' . $checked_attr . '>';

        // Titre + date de livraison
        echo '<div class="ispag-article-header">';
        echo '<span class="ispag-article-title">' . $titre . '</span>';

        if (!empty($article->TimestampDateDeLivraison)) {
            $date_livraison = date('d.m.Y', $article->TimestampDateDeLivraison);
            echo '<div class="ispag-article-date">📦 ' . esc_html__('Est. delivery:', 'creation-reservoir') . ' ' . esc_html($date_livraison) . '</div>';
        }

        echo '</div>';


        // Statut & Facturation
        echo '<div class="ispag-article-status">';
        echo '<div class="ispag-article-livre">' . esc_html($status) . '</div>';
        echo '<div class="ispag-article-facture">' . esc_html($facture) . '</div>';
        echo '</div>';

        // Quantité, prix, rabais, net
        echo '<div class="ispag-article-prices">';
        echo '<div class="ispag-article-qty">' . __('Quantity', 'creation-reservoir') . ' : ' . $qty . '</div>';
        echo $user_can_manage_order ? '<div class="ispag-article-prix-brut">' . __('Gross unit price', 'creation-reservoir') . ' : ' . $prix_brut . ' €</div>' : '';
        echo $user_can_manage_order ? '<div class="ispag-article-rabais">' . __('Discount', 'creation-reservoir') . ' : ' . $rabais . ' %</div>' : '';
        echo $user_can_manage_order ? '<div class="ispag-article-prix-net">' . __('Net price', 'creation-reservoir') . ' : ' . $prix_net . ' €</div>' : '';
        echo '</div>';

        // Boutons d'actions
        echo '<div class="ispag-article-actions">';
        echo '<button class="ispag-btn ispag-btn-view" data-article-id="' . $id . '">' . __('See product', 'creation-reservoir') . '</button>';
        echo '<button class="ispag-btn ispag-btn-edit" data-article-id="' . $id . '">' . __('Edit product', 'creation-reservoir') . '</button>';
        echo $user_can_manage_order ? '<button class="ispag-btn ispag-btn-copy" data-article-id="' . $id . '">' . __('Replicate', 'creation-reservoir') . '</button>' : '';
        echo $user_can_manage_order ? '<button class="ispag-btn ispag-btn-delete" data-article-id="' . $id . '">' . __('Delete', 'creation-reservoir') . '</button>' : '';
        echo '</div>';

        echo '</div>'; // .ispag-article
    }

}


add_action('wp_ajax_ispag_update_phase_status', 'ispag_update_phase_status');
function ispag_update_phase_status() {
    error_log('[ispag_update_phase_status] Envoi message ');
    global $wpdb;

    $deal_id = intval($_POST['deal_id']);
    $slug = sanitize_text_field($_POST['slug_phase']);
    $status_id = intval($_POST['status_id']);

    $table = $wpdb->prefix . 'achats_suivi_phase_commande';
    $meta_table = $wpdb->prefix . 'achats_meta_phase_commande';

    // Update ou insert
    $existing = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table WHERE hubspot_deal_id = %d AND slug_phase = %s",
        $deal_id, $slug
    ));

    if ($existing) {
        $wpdb->update($table, ['status_id' => $status_id], ['hubspot_deal_id' => $deal_id, 'slug_phase' => $slug]);
    } else {
        $wpdb->insert($table, ['hubspot_deal_id' => $deal_id, 'slug_phase' => $slug, 'status_id' => $status_id]);
    }
    if($status_id == 1){
        // $Mail = new \wp_gestion\class\Mail();
        // $array['template_id'] = $Mail->getBrevoTemplateId($slug_phase);
        // $array['Brevo_delay_days'] = $Mail->getBrevoDelayDays($slug_phase);
        // $array['brevo'] = ($status_id == 1 AND !empty($hubspot_deal_id)) ? brevo_send_email_with_pdf($hubspot_deal_id, $array['template_id'], $array['Brevo_delay_days']) : null;

        $notifier = new ISPAG_Telegram_Notifier('8084863181');

        // // Ajouter un abonné (optionnel pour le moment)
        // $notifier->add_subscriber(123456789, 'Jean Dupont');

        // Envoyer une notification
        $message = $notifier->get_message($slug, $deal_id);
        $notifier->send_message($message, true, false, $deal_id);
    }

    // Retourner le nom et couleur pour MAJ visuelle
    $meta = $wpdb->get_row($wpdb->prepare("SELECT Nom, Couleur FROM $meta_table WHERE Id = %d", $status_id));
    wp_send_json_success([
        'name' => $meta->Nom,
        'color' => $meta->Couleur
    ]);
}

function display_ispag_suivis($deal_id, $isQuotation = false){
    $phases = (new ISPAG_Phase_Repository())->get_project_phases($deal_id, $isQuotation);

    if ($phases) {
        echo '<div class="ispag-table-responsive">'; // ✅ conteneur responsive
        echo '<table class="ispag-phase-table">';
        $headers = [
            0 => __('Step', 'creation-reservoir'),
            1 => __('Status', 'creation-reservoir'),
            2 => __('Date', 'creation-reservoir'),
        ];

        echo '<thead><tr>';
        foreach ($headers as $key => $title) {
            echo '<th data-key="' . esc_attr($key) . '">' . esc_html($title) . '</th>';
        }
        echo '</tr></thead><tbody>';


        $can_view_all = current_user_can('manage_order');
        $can_edit = current_user_can('manage_order');

        $classes = 'suivi-button';
        $classes .= ' editable-status';
        if (!$can_edit) {
            $classes .= ' non-editable';
        }

        $i = 0;
        foreach ($phases as $phase) {
            if (!$can_view_all && (int)$phase->VisuClient !== 1) {
                continue;
            }
            echo '<tr>';
            echo '<td>' . esc_html($phase->TitrePhase) . '</td>';
            $statut = '<span class="' . esc_attr($classes) . '" 
                data-deal="' . esc_attr($deal_id) . '" 
                data-phase="' . esc_attr($phase->SlugPhase) . '" 
                data-current="' . esc_attr($phase->status_id ?? '') . '"
                style="background-color: ' . esc_attr($phase->statut_couleur) . ';">' 
                . esc_html__($phase->statut_nom, 'creation-reservoir') . '</span>';
            echo '<td>' . $statut . '</td>';
            echo '<td>' . ($phase->date_modification ? date('d.m.Y', strtotime($phase->date_modification)) : '-') . '</td>';
            echo '</tr>';
            $i++;
        }

        echo '</tbody></table>';
        echo '</div>'; // ✅ fermeture du conteneur responsive

    } else {
        echo '<p>' . __('No phase defined for this project', 'creation-reservoir') . '</p>';
    }
}


function display_ispag_doc_manger($deal_id){
    $docManager = new ISPAG_Document_Manager();
    $docs = $docManager->get_documents_grouped_by_article($deal_id, false);
    echo $docManager->render_grouped_documents($docs);
}

function display_ispag_project_details($deal_id){
    return (new ISPAG_Project_Details_Renderer())->display($deal_id);
}

function display_ispag_project_articles($deal_id){
    $articles = new ISPAG_Article_Repository();
    // echo '<pre>';
    // var_dump($deal_id);
    // var_dump($articles->get_articles_by_deal($deal_id));
    // echo '</pre>';
    echo (new ISPAG_Detail_Page)->render_articles_list($articles->get_articles_by_deal($deal_id));
    echo '<button id="ispag-add-article" class="ispag-btn ispag-btn-primary">➕ ' . __('Add product', 'creation-reservoir'). '</button>';
}