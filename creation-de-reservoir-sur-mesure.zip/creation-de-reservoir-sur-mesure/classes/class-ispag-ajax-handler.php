<?php


class ISPAG_Ajax_Handler {
    public static function init() {
        add_action('wp_ajax_ispag_inline_edit_field', [self::class, 'inline_edit_field']);
    }

    public static function inline_edit_field() {
        $deal_id = intval($_POST['deal_id']);
        $field   = sanitize_text_field($_POST['field']);
        $value   = sanitize_text_field($_POST['value']);
        $source  = sanitize_text_field($_POST['source'] ?? 'delivery');

        if (!current_user_can('manage_order') && !ISPAG_Projet_Repository::is_user_project_owner($deal_id)) {
            wp_send_json_error('Non autorisé');
        }

        global $wpdb;

        // Définir selon la source
        if ($source === 'project') {
            $allowed_fields = ['NumCommande', 'customer_order_id', 'Ingenieur', 'EnSoumission'];
            $table = $wpdb->prefix . 'achats_liste_commande';
        } else {
            $allowed_fields = ['City', 'AdresseDeLivraison', 'PersonneContact', 'num_tel_contact', 'DeliveryAdresse2'];
            $table = $wpdb->prefix . 'achats_info_commande';
        }

        if (!in_array($field, $allowed_fields)) {
            wp_send_json_error(__('Field not allowed', 'creation-reservoir'));
        }

        // UPDATE ou INSERT selon source
        if ($source === 'project') {
            $updated = $wpdb->update($table, [$field => $value], ['hubspot_deal_id' => $deal_id]);
        } else {
            $exists = $wpdb->get_var(
                $wpdb->prepare("SELECT COUNT(*) FROM $table WHERE hubspot_deal_id = %d", $deal_id)
            );

            if ($exists) {
                $updated = $wpdb->update($table, [$field => $value], ['hubspot_deal_id' => $deal_id]);
            } else {
                $updated = $wpdb->insert($table, [
                    'hubspot_deal_id' => $deal_id,
                    $field => $value
                ]);
            }
        }

        if ($updated !== false) {
            wp_send_json_success(['message' => __('Updated', 'creation-reservoir')]);
        } else {
            wp_send_json_error(__('Error while saving', 'creation-reservoir'));
        }
    }


}
