<?php


class ISPAG_Ajax_Handler {
    public static function init() {
        add_action('wp_ajax_ispag_inline_edit_field', [self::class, 'inline_edit_field']);
        add_action('wp_ajax_ispag_load_article_modal', [self::class, 'load_article_modal']);
        add_action('wp_ajax_ispag_load_article_edit_modal', [self::class, 'load_article_edit_modal']);
        add_action('wp_ajax_ispag_get_standard_article_data', [self::class, 'get_standard_article_data']);
        add_action('wp_ajax_ispag_get_standard_article_info', [self::class, 'get_standard_article_info']);
        add_action('wp_ajax_ispag_save_article', [self::class, 'save_article']);
        add_action('wp_ajax_ispag_reload_article_row', [self::class, 'reload_article_row']);
        add_action('wp_ajax_ispag_open_new_article_modal', [self::class, 'open_new_article_modal']);
        add_action('wp_ajax_ispag_load_article_create_modal', [self::class, 'load_article_create_modal']);
        add_action('wp_ajax_ispag_delete_article', [self::class, 'delete_article']);
    }

    public static function inline_edit_field() {
        $deal_id = intval($_POST['deal_id']);
        $field   = sanitize_text_field($_POST['field']);
        $value   = sanitize_text_field($_POST['value']);
        $source  = sanitize_text_field($_POST['source'] ?? 'delivery');

        if (!current_user_can('manage_order') && !ISPAG_Projet_Repository::is_user_project_owner($deal_id)) {
            wp_send_json_error('Non autorisé');
        }

        global $wpdb;

        // Définir selon la source
        if ($source === 'project') {
            $allowed_fields = ['NumCommande', 'customer_order_id', 'Ingenieur', 'EnSoumission'];
            $table = $wpdb->prefix . 'achats_liste_commande';
        } else {
            $allowed_fields = ['City', 'AdresseDeLivraison', 'PersonneContact', 'num_tel_contact', 'DeliveryAdresse2'];
            $table = $wpdb->prefix . 'achats_info_commande';
        }

        if (!in_array($field, $allowed_fields)) {
            wp_send_json_error(__('Field not allowed', 'creation-reservoir'));
        }

        // UPDATE ou INSERT selon source
        if ($source === 'project') {
            $updated = $wpdb->update($table, [$field => $value], ['hubspot_deal_id' => $deal_id]);
        } else {
            $exists = $wpdb->get_var(
                $wpdb->prepare("SELECT COUNT(*) FROM $table WHERE hubspot_deal_id = %d", $deal_id)
            );

            if ($exists) {
                $updated = $wpdb->update($table, [$field => $value], ['hubspot_deal_id' => $deal_id]);
            } else {
                $updated = $wpdb->insert($table, [
                    'hubspot_deal_id' => $deal_id,
                    $field => $value
                ]);
            }
        }

        if ($updated !== false) {
            wp_send_json_success(['message' => __('Updated', 'creation-reservoir')]);
        } else {
            wp_send_json_error(__('Error while saving', 'creation-reservoir'));
        }
    }

    public static function load_article_modal() {
        $id = intval($_POST['article_id']);
        $repo = new ISPAG_Article_Repository();
        $article = $repo->get_article_by_id($id);
        if (!$article) {
            echo '<p>Article introuvable.</p>';
            wp_die();
        }

        $user_can = current_user_can('manage_order');

        echo '<h2>' . esc_html($article->Article) . '</h2>';
        echo '<div class="ispag-modal-grid">';

            // Gauche : image + description
            echo '<div class="ispag-modal-left">';
                echo '<img src="' . plugin_dir_url(__FILE__) . '../assets/img/placeholder.webp" alt="Image article" />';
                
            echo '</div>';

            // Droite : données clés
            echo '<div class="ispag-modal-right">';
                echo '<p>' . nl2br(esc_html($article->Description)) . '</p>';
            echo '</div>';

        echo '</div>'; // .ispag-modal-grid

        echo '<div class="ispag-modal-grid ispag-bloc-common">';
            // Gauche : dates et fournisseur
            echo '<div class="ispag-modal-left">';
                echo '<div class="ispag-modal-meta">';
                    if ($user_can) {
                        echo '<p><strong>' . __('Supplier', 'creation-reservoir') . ':</strong> ' . esc_html($article->fournisseur_nom) . '</p>';
                    }
                    echo '<p><strong>' . __('Factory departure date', 'creation-reservoir') . ':</strong> ' . ($article->TimestampDateDeLivraison ? date('d.m.Y', $article->TimestampDateDeLivraison) : '-') . '</p>';
                    echo '<p><strong>' . __('Delivery ETA', 'creation-reservoir') . ':</strong> ' . ($article->TimestampDateDeLivraisonFin ? date('d.m.Y', $article->TimestampDateDeLivraisonFin) : '-') . '</p>';
                echo '</div>';
            echo '</div>';
            echo '<div class="ispag-modal-right">';
                echo '<p><strong>' . __('Group', 'creation-reservoir') . ':</strong> ' . esc_html($article->Groupe) . '</p>';
                if ($user_can) {
                    echo '<p><strong>' . __('Master article', 'creation-reservoir') . ':</strong> ' . esc_html($article->IdArticleMaster) . '</p>';
                }
                echo '<p><strong>' . __('Quantity', 'creation-reservoir') . ':</strong> ' . intval($article->Qty) . '</p>';
                echo '<p><strong>' . __('Gross unit price', 'creation-reservoir') . ':</strong> ' . number_format($article->sales_price, 2) . ' €</p>';
                echo '<p><strong>' . __('Discount', 'creation-reservoir') . ':</strong> ' . number_format($article->discount, 2) . ' %</p>';
            echo '</div>';
            
        echo '</div>'; // .ispag-modal-grid
        // Droite : statuts
        if ($user_can) {
            
            echo '<div class="ispag-modal-status">';
                echo '<p>' . __('Purchase requested', 'creation-reservoir') . ': ' . ($article->DemandeAchatOk ? '✅' : '❌') . '</p>';
                echo '<p>' . __('Drawing approved', 'creation-reservoir') . ': ' . ((int)$article->DrawingApproved === 1 ? '✅' : '❌') . '</p>';
                echo '<p>' . __('Delivered', 'creation-reservoir') . ': ' . ($article->Livre ? '✅' : '❌') . '</p>';
                echo '<p>' . __('Invoiced', 'creation-reservoir') . ': ' . ($article->invoiced ? '✅' : '❌') . '</p>';
            echo '</div>';
            
        }
        wp_die();
    }

    public static function load_article_edit_modal() {
        $id = intval($_POST['article_id']);
        $repo = new ISPAG_Article_Repository();
        $article = $repo->get_article_by_id($id);

        if (!$article) {
            echo '<p>Article introuvable.</p>';
            wp_die();
        }

        $groupes = $repo->get_groupes_by_deal($article->hubspot_deal_id);
        $standard_titles = $repo->get_standard_titles_by_type($article->Type);

        self::render_article_modal_form($article, $groupes, $standard_titles);
        wp_die();
    }
    public static function load_article_create_modal() {
        $type_id = intval($_POST['type_id']);
        $deal_id = intval($_POST['deal_id']);

        if (!$type_id || !$deal_id) {
            echo '<p>' . __('Missing parameters.', 'creation-reservoir') . '</p>';
            wp_die();
        }

        $repo = new ISPAG_Article_Repository();

        // Créer un "article vide" avec les valeurs par défaut
        $article = (object) [
            'Id' => 0,
            'Article' => '',
            'Description' => '',
            'Type' => $type_id,
            'fournisseur_nom' => '',
            'TimestampDateDeLivraisonFin' => null,
            'TimestampDateDeLivraison' => null,
            'Groupe' => '',
            'IdArticleMaster' => 0,
            'Qty' => 1,
            'sales_price' => '',
            'discount' => 0,
            'DemandeAchatOk' => false,
            'DrawingApproved' => false,
            'Livre' => false,
            'invoiced' => false,
        ];
        $article->master_articles = $repo->get_article_and_group($deal_id);

        $standard_titles = $repo->get_standard_titles_by_type($type_id);
        $groupes = $repo->get_groupes_by_deal($deal_id);

        self::render_article_modal_form($article, $groupes, $standard_titles, true);

        wp_die();
    }




    public static function get_standard_article_data() {
        $titre = sanitize_text_field($_POST['titre']);
        $type = intval($_POST['type']);

        if (!$titre || !$type) wp_send_json_error('Paramètres manquants');

        global $wpdb;
        $table_standard = $wpdb->prefix . 'achats_articles';

        $data = $wpdb->get_row(
            $wpdb->prepare("SELECT description_ispag, sales_price, IdFournisseur FROM $table_standard WHERE TitreArticle = %s AND TypeArticle = %d LIMIT 1", $titre, $type),
            ARRAY_A
        );

        if (!$data) {
            wp_send_json_error('Article non trouvé');
        }

        wp_send_json_success($data);
    }

    public static function get_standard_article_info() {
        $title = sanitize_text_field($_POST['title']);
        $type = intval($_POST['type']);

        if (empty($title) || !$type) {
            wp_send_json_error(['message' => 'Paramètres invalides.']);
        }

        // 🔄 Convertit les caractères spéciaux en entités HTML
        $encoded_title = htmlentities($title, ENT_NOQUOTES, 'UTF-8');

        $repo = new ISPAG_Article_Repository();
        $article = $repo->get_standard_article_by_title($encoded_title, $type);

        wp_send_json_success([
            'title' => $encoded_title, // debug
            'type' => $type,
            'article' => $article,
        ]);
    }

    // public static function save_article() {
    //     global $wpdb;

    //     $id = intval($_POST['article_id']);
    //     if (!$id) {
    //         wp_send_json_error(['message' => 'ID article invalide']);
    //     }

    //     $data = [
    //         'Article' => sanitize_text_field($_POST['article_title']),
    //         'Description' => wp_kses_post($_POST['description']),
    //         'sales_price' => floatval($_POST['sales_price']),
    //         'discount' => floatval($_POST['discount']),
    //         'Qty' => intval($_POST['qty']),
    //         'Groupe' => sanitize_text_field($_POST['group']),
    //         'IdArticleMaster' => isset($_POST['master_article']) ? intval($_POST['master_article']) : 0,
    //         'TimestampDateDeLivraisonFin' => $_POST['date_depart'] ? strtotime($_POST['date_depart']) : null,
    //         'TimestampDateDeLivraison' => $_POST['date_eta'] ? strtotime($_POST['date_eta']) : null,
    //         'DemandeAchatOk' => isset($_POST['DemandeAchatOk']) ? 1 : 0,
    //         'DrawingApproved' => isset($_POST['DrawingApproved']) ? 1 : 0,
    //         'Livre' => isset($_POST['Livre']) ? 1 : 0,
    //         'invoiced' => isset($_POST['invoiced']) ? 1 : 0,
    //     ];

    //     $updated = $wpdb->update(
    //         $wpdb->prefix . 'achats_details_commande',
    //         $data,
    //         ['Id' => $id],
    //         null,
    //         ['%d']
    //     );

    //     if ($updated === false) {
    //         wp_send_json_error(['message' => 'Erreur BDD']);
    //     }

    //     wp_send_json_success(['message' => 'Article mis à jour']);
    // }
    public static function save_article() {
        global $wpdb;

        $id = isset($_POST['article_id']) ? intval($_POST['article_id']) : 0;

        // 🔍 Convertir le nom du fournisseur en ID
        $supplier_name = sanitize_text_field($_POST['supplier'] ?? '');
        $supplier_id = null;
        if (!empty($supplier_name)) {
            $supplier_id = $wpdb->get_var($wpdb->prepare(
                "SELECT Id FROM {$wpdb->prefix}achats_fournisseurs WHERE Fournisseur = %s",
                $supplier_name
            ));
            
            if (!$supplier_id) {
                wp_send_json_error(['message' => "Fournisseur '$supplier_name' introuvable."]);
            }
        }


        $data = [
            'Article' => isset($_POST['article_title']) ? sanitize_text_field($_POST['article_title']) : '',
            'Description' => isset($_POST['description']) ? wp_kses_post($_POST['description']) : '',
            'sales_price' => isset($_POST['sales_price']) ? floatval($_POST['sales_price']) : 0,
            'discount' => isset($_POST['discount']) ? floatval($_POST['discount']) : '',
            'Qty' => isset($_POST['qty']) ? intval($_POST['qty']) : 0,

            'Groupe' => isset($_POST['group']) ? sanitize_text_field($_POST['group']) : ' ',
            'IdArticleMaster' => isset($_POST['master_article']) ? intval($_POST['master_article']) : 0,
            'TimestampDateDeLivraisonFin' => isset($_POST['date_eta']) && $_POST['date_eta'] ? strtotime($_POST['date_eta']) : null,
            'TimestampDateDeLivraison' => isset($_POST['date_depart']) && $_POST['date_depart'] ? strtotime($_POST['date_depart']) : null,
            'DemandeAchatOk' => isset($_POST['DemandeAchatOk']) ? 1 : null,
            'DrawingApproved' => isset($_POST['DrawingApproved']) ? 1 : null,
            'Livre' => isset($_POST['Livre']) ? 1 : null,
            'invoiced' => isset($_POST['invoiced']) ? time() : null,
        ];

        if ($supplier_id !== null) {
            $data['IdFournisseur'] = $supplier_id;
        }

        // 🔧 CREATION (si pas d'ID existant)
        if (!$id) {
            $type = isset($_POST['type']) ? intval($_POST['type']) : 0;
            $deal_id = isset($_POST['deal_id']) ? intval($_POST['deal_id']) : 0;

            if (!$type || !$deal_id) {
                wp_send_json_error(['message' => 'Type ou deal_id manquant.', 'type' => $type, 'deal_id' => $deal_id]);
            }

            $data['Type'] = $type;
            $data['hubspot_deal_id'] = $deal_id;

            $inserted = $wpdb->insert(
                $wpdb->prefix . 'achats_details_commande',
                $data
            );

            if ($inserted === false) {
                wp_send_json_error(['message' => 'Erreur lors de la création']);
            }

            $new_id = $wpdb->insert_id;
            wp_send_json_success(['message' => 'Article créé', 'article_id' => $new_id]);
        }

        // 🔧 MISE À JOUR
        $updated = $wpdb->update(
            $wpdb->prefix . 'achats_details_commande',
            $data,
            ['Id' => $id]
        );

        if ($updated === false) {
            wp_send_json_error(['message' => 'Erreur lors de la mise à jour']);
        }

        wp_send_json_success(['message' => 'Article mis à jour', 'article_id' => $id]);
    }



    public static function reload_article_row() {
        $id = intval($_POST['article_id']);
        $is_secondary = intval($_POST['is_secondary']);
        $repo = new ISPAG_Article_Repository();
        $article = $repo->get_article_by_id($id);

        if (!$article) {
            wp_send_json_error(['message' => 'Article introuvable']);
        }

        // Tu réutilises ici le même HTML que celui généré dans la liste initiale

        $article_detail = new ISPAG_Detail_Page();
        ob_start();
        echo $article_detail->render_article_block($article, $is_secondary);
        
        $html = ob_get_clean();
        echo $html;
        wp_die();
    }

    public static function open_new_article_modal() {
        global $wpdb;

        $table_prestation = $wpdb->prefix . 'achats_type_prestations';
        $types = $wpdb->get_results("SELECT Id, type FROM $table_prestation ORDER BY sort ASC");

        echo '<div id="ispag-product-type-selector">';
        echo '<h2>' . __('Add product', 'creation-reservoir') . '</h2>';
        echo '<div class="ispag-modal-select-type">';
        echo '<label>' . __('Choose article typ', 'creation-reservoir') . ' :<br>';
        echo '<select id="new-article-type">';
        echo '<option value="">-- ' . __('Choose', 'creation-reservoir') . ' --</option>';
        foreach ($types as $type) {
            echo '<option value="' . esc_attr($type->Id) . '">' . esc_html($type->type) . '</option>';
        }
        echo '</select></label>';
        echo '</div>';
        echo '</div>';

        echo '<div id="new-article-form-container"></div>'; // Contenu dynamique ensuite

        wp_die();
    }

    private static function render_article_modal_form($article, $groupes, $standard_titles, $is_new = false) {
        $user_can = current_user_can('manage_order');
        $id_attr = $is_new ? '' : ' data-article-id="' . intval($article->Id) . '"';

        // echo'<pre>';
        // var_dump($article);
        // echo'</pre>';
        
        echo '<h2>' . ($is_new ? __('New article', 'creation-reservoir') : __('Edit article', 'creation-reservoir') . ' : ' . esc_html($article->Article)) . '</h2>';
        echo '<form class="ispag-edit-article-form"' . $id_attr . '>';

            echo '<div class="ispag-modal-grid">';
            if ($is_new) {
                echo '<input type="hidden" name="type" value="' . esc_attr($article->Type) . '">';
            }

                // Zone gauche : image + description
                echo '<div class="ispag-modal-left">';
                    echo '<img src="' . plugin_dir_url(__FILE__) . '../assets/img/placeholder.webp" alt="Image article" />';
                echo '</div>';

                // Zone droite : données modifiables
                echo '<div class="ispag-modal-right" id="ispag-title-description-area">';
                    if ($article->Type == 1):
                        echo '<div id="ispag-tank-form-container">';
                        do_action('ispag_render_tank_form', $article->Id);
                        echo '</div>';
                    else:
                    

                    echo '<label>' . __('Title', 'creation-reservoir') . '<br>';
                    echo '<input type="text" name="article_title" value="' . esc_attr($article->Article) . '" list="standard-titles" id="article-title" data-type="'. esc_attr($article->Type) .'">';
                    echo '<datalist id="standard-titles">';
                    foreach ($standard_titles as $title) {
                        echo '<option value="' . esc_attr($title) . '">';
                    }
                    echo '</datalist>';
                    echo '</label>';
                    echo '<br/>';
                    echo '<label>' . __('Description', 'creation-reservoir') . '<br>';
                    echo '<textarea name="description" id="article-description" cols="40" rows="15">' . esc_textarea($article->Description) . '</textarea>';
                    echo '</label>';
                
                endif;


                    

                    

                echo '</div>'; // .ispag-modal-right

            echo '</div>'; // .ispag-modal-grid

            echo '<div class="ispag-modal-grid ispag-bloc-common">';
                // Zone gauche : Dates de livraison et fournisseur
                echo '<div class="ispag-modal-left">';
                    // Dates
                    echo '<div class="ispag-modal-meta">';

                        if ($user_can) {
                            echo '<label>' . __('Supplier', 'creation-reservoir') . '<br>';
                            echo '<input type="text" name="supplier" value="' . esc_attr($article->fournisseur_nom) . '" list="supplier-list" ><datalist id="supplier-list"></datalist></label>';
                        }
                        echo '<label>' . __('Factory departure date', 'creation-reservoir') . '<br>';
                        echo '<input type="date" name="date_depart" value="' . ($article->TimestampDateDeLivraison ? date('Y-m-d', $article->TimestampDateDeLivraisonFin) : '') . '"></label>';

                        echo '<label>' . __('Delivery ETA', 'creation-reservoir') . '<br>';
                        echo '<input type="date" name="date_eta" value="' . ($article->TimestampDateDeLivraisonFin ? date('Y-m-d', $article->TimestampDateDeLivraison) : '') . '"></label>';
                    echo '</div>';
                echo '</div>';
                        
                // Zone droite : données modifiables
                echo '<div class="ispag-modal-right">';
                    echo '<label>' . __('Group', 'creation-reservoir') . '<br>';
                    echo '<input type="text" name="group" list="group-list" value="' . esc_attr($article->Groupe) . '">';
                    echo '<datalist id="group-list">';
                    foreach ($groupes as $groupe) {
                        echo '<option value="' . esc_attr($groupe) . '">';
                    }
                    echo '</datalist></label>';


                    if ($user_can) {
                        echo '<label>' . __('Master article', 'creation-reservoir') . '<br>';
                        echo '<select name="master_article">';
                        echo '<option value="0">—</option>';
                        $grouped = [];
                        foreach ($article->master_articles as $groupe => $articles) {
                            echo "<optgroup label=\"" . esc_attr($groupe) . "\">";
                            foreach ($articles as $article_master) {
                                $selected = ($article->IdArticleMaster == $article_master->Id) ? 'selected' : '';
                                echo '<option value="' . esc_attr($article_master->Id) . '" ' . $selected . '>' . esc_html($article_master->Article) . '</option>';
                            }
                            echo "</optgroup>";
                        }
                        echo '</select>';
                        echo'</label>';
                    }

                    echo '<label>' . __('Quantity', 'creation-reservoir') . '<br>';
                    echo '<input type="number" name="qty" value="' . esc_attr($article->Qty) . '"></label>';

                    echo '<label>' . __('Gross unit price', 'creation-reservoir') . '<br>';
                    echo '<input type="text" name="sales_price" value="' . esc_attr($article->sales_price) . '"> €</label>';

                    echo '<label>' . __('Discount', 'creation-reservoir') . '<br>';
                    echo '<input type="text" name="discount" value="' . esc_attr($article->discount) . '"> %</label>';
                echo '</div>';
            echo '</div>'; // .ispag-modal-grid

        

        // Statuts
        if ($user_can) {
            echo '<div class="ispag-modal-status">';
            echo '<label><input type="checkbox" name="DemandeAchatOk" ' . ($article->DemandeAchatOk ? 'checked' : '') . '> ' . __('Purchase requested', 'creation-reservoir') . '</label><br>';
            echo '<label><input type="checkbox" name="DrawingApproved" ' . ((int)$article->DrawingApproved === 1 ? 'checked' : '') . '> ' . __('Drawing approved', 'creation-reservoir') . '</label><br>';
            echo '<label><input type="checkbox" name="Livre" ' . ($article->Livre ? 'checked' : '') . '> ' . __('Delivered', 'creation-reservoir') . '</label><br>';
            echo '<label><input type="checkbox" name="invoiced" ' . ($article->invoiced ? 'checked' : '') . '> ' . __('Invoiced', 'creation-reservoir') . '</label><br>';
            echo '</div>';
        }

        // Boutons
        echo '<div class="ispag-modal-actions">';
        echo '<button type="submit" class="ispag-btn ispag-btn-primary">' . __('Save', 'creation-reservoir') . '</button>';
        echo '<button type="button" class="ispag-btn ispag-btn-secondary" onclick="closeModal()">' . __('Cancel', 'creation-reservoir') . '</button>';
        echo '</div>';

        echo '</form>';
    }


    public static function delete_article() {
        global $wpdb;

        $id = isset($_POST['article_id']) ? intval($_POST['article_id']) : 0;
        if (!$id) {
            wp_send_json_error(['message' => 'ID manquant ou invalide']);
        }

        $deleted = $wpdb->delete(
            $wpdb->prefix . 'achats_details_commande',
            ['Id' => $id],
            ['%d']
        );

        if ($deleted === false) {
            wp_send_json_error(['message' => 'Erreur lors de la suppression']);
        }

        wp_send_json_success(['message' => 'Article supprimé']);
    }
}
