<?php
/*
Plugin Name: Création de réservoir sur mesure
Description: Gestion des projets et offres pour ISPAG. Liste l'ensemble des projets / offres en cours
Plugin URI: https://github.com/mougeat/creation-reservoir
Version: 1.0.3
Author: Cyril Barthel
Author URI: https://cyrilbarthel.com/
Text Domain: creation-reservoir
Domain Path: /languages
*/

defined('ABSPATH') or die('No script kiddies please!');

require_once plugin_dir_path(__FILE__) . 'classes/class-ispag-plugin-updater.php';
new ISPAG_Plugin_Updater(
    'creation-de-reservoir-sur-mesure',
    'creation-de-reservoir-sur-mesure/creation-de-reservoir-sur-mesure.php',
    'https://raw.githubusercontent.com/mougeat/creation-reservoir/main/update.json'
);

add_action('admin_init', function() {
    delete_site_transient('update_plugins');
});

// $remote = wp_remote_get('https://github.com/mougeat/creation-reservoir/update.json');
// require_once plugin_dir_path(__FILE__) . 'classes/class-plugin-updater.php';

spl_autoload_register(function ($class) {
    $prefix = 'ISPAG_';
    $base_dir = __DIR__ . '/classes/';
    if (strpos($class, $prefix) === 0) {
        $class_name = strtolower(str_replace('_', '-', $class));
        $file = $base_dir . 'class-' . $class_name . '.php';
        if (file_exists($file)) {
            require $file;
        }
    }
});

register_activation_hook(__FILE__, ['ISPAG_Installer', 'install']);



function ispag_load_textdomain() {
    load_plugin_textdomain('creation-reservoir', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}
add_action('plugins_loaded', 'ispag_load_textdomain');
new ISPAG_Projet_Creation();
add_action('init', function () {
    ISPAG_Project_Manager::init();
    ISPAG_Achat_Manager::init();
    ISPAG_Detail_Page::init();
    ISPAG_Telegram_Admin::init();
    ISPAG_Ajax_Handler::init();
});
