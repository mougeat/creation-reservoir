<?php
/*
Plugin Name: Création de réservoir sur mesure
Description: Gestion des projets et offres pour ISPAG.
Version: 1.0
Author: Cyril Barthel
Text Domain: creation-reservoir
Domain Path: /languages
*/

defined('ABSPATH') or die('No script kiddies please!');

spl_autoload_register(function ($class) {
    $prefix = 'ISPAG_';
    $base_dir = __DIR__ . '/classes/';
    if (strpos($class, $prefix) === 0) {
        $class_name = strtolower(str_replace('_', '-', $class));
        $file = $base_dir . 'class-' . $class_name . '.php';
        if (file_exists($file)) {
            require $file;
        }
    }
});

function ispag_load_textdomain() {
    load_plugin_textdomain('creation-reservoir', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}
add_action('plugins_loaded', 'ispag_load_textdomain');

add_action('init', function () {
    ISPAG_Project_Manager::init();
});
