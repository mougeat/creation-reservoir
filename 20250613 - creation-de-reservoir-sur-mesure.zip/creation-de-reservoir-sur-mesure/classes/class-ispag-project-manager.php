<?php
defined('ABSPATH') or die();

class ISPAG_Project_Manager {

    public static function init() {
        add_shortcode('ispag_projets', [self::class, 'shortcode_projets']);
        add_action('wp_enqueue_scripts', [self::class, 'enqueue_assets']);
    }

    public static function enqueue_assets() {
        wp_enqueue_style('ispag-style', plugin_dir_url(__FILE__) . '../assets/css/style.css');
    }

    public static function shortcode_projets($atts) {
        $atts = shortcode_atts([
            'actif' => null // Par défaut : ne filtre pas
        ], $atts);

        $qotation = isset($_GET['qotation']) && $_GET['qotation'] == 1;

        $current_user_id = get_current_user_id();
        $can_view_all = current_user_can('real_all_orders');
        $can_view_own = current_user_can('read_orders');

        $projetRepo = new ISPAG_Projet_Repository(true);

        if ($can_view_all) {
            $projects = $projetRepo->get_projects_or_offers($qotation, null, true);
        } elseif ($can_view_own) {
            $projects = $projetRepo->get_projects_or_offers($qotation, $current_user_id, false);
        } else {
            return '<p>' . __('Vous n\'avez pas les droits pour voir cette page.', 'creation-reservoir') . '</p>';
        }

        // ✅ Filtrage des projets actifs si demandé dans les attributs
        if ($atts['actif'] == '1') {
            $projects = array_filter($projects, fn($p) => $p->CmdActif == 1);
        }

        return self::render_table($projects, $qotation);
    }


    // Méthode de rendu du tableau
    public static function render_table($projects, $is_quotation) {
        if (empty($projects)) {
            return '<p>' . __('Aucun projet ou offre trouvé.', 'creation-reservoir') . '</p>';
        }

        $current_user = wp_get_current_user();
        $show_price = current_user_can('real_all_orders') || in_array('administrator', $current_user->roles);

        $output = '<div class="ispag-table-wrapper">';
        $output .= '<table class="ispag-project-table">';
        $output .= '<thead><tr>';
        $output .= '<th></th>';
        $output .= '<th>' . __('Project name', 'creation-reservoir') . '</th>';
        $output .= '<th>' . __('Total price', 'creation-reservoir') . '</th>';
        $output .= '<th>' . __('States', 'creation-reservoir') . '</th>';
        

        if (!$is_quotation) {
            $output .= '<th>' . __('Tank delivery date', 'creation-reservoir') . '</th>';
            $output .= '<th>' . __('Welding date', 'creation-reservoir') . '</th>';
            $output .= '<th>' . __('Insulation date', 'creation-reservoir') . '</th>';
        }

        $output .= '<th>' . __('Contact', 'creation-reservoir') . '</th>';
        $output .= '<th>' . __('Company', 'creation-reservoir') . '</th>';
        $output .= '</tr></thead><tbody>';

        // $projetSuivi = new ISPAG_Projet_Suivi();
        $i = 0;
        foreach ($projects as $p) {
            
            $bgcolor = !empty($p->next_phase->Color) ? esc_attr($p->next_phase->Color) : '#ccc'; // gris clair par défaut
            $row_class = ($i % 2 === 1) ? ' style="background-color:#f0f0f0;"' : '';
            $output .= '<tr' . $row_class . '>';
            $output .= '<td style="background-color:#b8e994;"></td>';
            $output .= '<td><a href="' . $p->project_url . '" target="_blank" rel="noopener noreferrer">' . esc_html($p->ObjetCommande) . '</a></td>';

            if ($show_price) {
                $output .= '<td>' . number_format($p->prix_net, 2, ',', ' ') . ' CHF</td>';
            } else {
                $output .= '<td>&mdash;</td>';
            }

            
            $text = __(esc_html($p->next_phase->TitrePhase),"creation-reservoir");
            $badge = "<span  class=\"badge bg-{$bgcolor} text-dark\" style=\"--bs-bg-opacity: 0.5; padding: 3px 6px; font-size: 0.8rem;\">{$text}</span>";
            // $badge = '&mdash;';
            $output .= '<td>' . $badge . '</td>';
            

            if (!$is_quotation) {
                
                $output .= '<td>' . $p->bar_product . '</td>';
                $output .= '<td>' . $p->bar_welding . '</td>';
                $output .= '<td>' . $p->bar_isol . '</td>';
            }

            $output .= '<td>' . esc_html($p->contact_name) . '</td>';
            $output .= '<td>' . esc_html($p->nom_entreprise) . '</td>';
            $output .= '</tr>';

            $i++;
        }

        $output .= '</tbody></table>';
        $output .= '</div>';

        return $output;
    }

}
