<?php
defined('ABSPATH') or die();

class ISPAG_Reservoir_Manager {

    public static function init() {
        add_shortcode('ispag_projets', [self::class, 'shortcode_projets']);
        add_action('wp_enqueue_scripts', [self::class, 'enqueue_assets']);
    }

    public static function enqueue_assets() {
        wp_enqueue_style('ispag-style', plugin_dir_url(__FILE__) . '../assets/css.css');
    }

    public static function shortcode_projets($atts) {
        $atts = shortcode_atts([
            'actif' => null // Par défaut : ne filtre pas
        ], $atts);

        $qotation = isset($_GET['qotation']) && $_GET['qotation'] == 1;

        $current_user_id = get_current_user_id();
        $can_view_all = current_user_can('real_all_orders');
        $can_view_own = current_user_can('read_orders');

        $projetRepo = new ISPAG_Projet_Repository();

        if ($can_view_all) {
            $projects = $projetRepo->get_projects_or_offers($qotation, null, true);
        } elseif ($can_view_own) {
            $projects = $projetRepo->get_projects_or_offers($qotation, $current_user_id, false);
        } else {
            return '<p>' . __('Vous n\'avez pas les droits pour voir cette page.', 'creation-reservoir') . '</p>';
        }

        // ✅ Filtrage des projets actifs si demandé dans les attributs
        if ($atts['actif'] == '1') {
            $projects = array_filter($projects, fn($p) => $p->CmdActif == 1);
        }

        return self::render_table($projects, $qotation);
    }


    // Méthode de rendu du tableau
    public static function render_table($projects, $is_quotation) {
        if (empty($projects)) {
            return '<p>' . __('Aucun projet ou offre trouvé.', 'creation-reservoir') . '</p>';
        }

        $current_user = wp_get_current_user();
        $show_price = current_user_can('real_all_orders') || in_array('administrator', $current_user->roles);

        $output = '<table class="ispag-project-table">';
        $output .= '<thead><tr>';
        $output .= '<th style="background-color:#b8e994;"></th>';
        $output .= '<th>' . __('Project name', 'creation-reservoir') . '</th>';
        $output .= '<th>' . __('Total price', 'creation-reservoir') . '</th>';
        $output .= '<th>' . __('Contact', 'creation-reservoir') . '</th>';
        $output .= '<th>' . __('Company', 'creation-reservoir') . '</th>';

        if (!$is_quotation) {
            $output .= '<th>' . __('Tank delivery date', 'creation-reservoir') . '</th>';
            $output .= '<th>' . __('Welding date', 'creation-reservoir') . '</th>';
            $output .= '<th>' . __('Insulation date', 'creation-reservoir') . '</th>';
        }

        $output .= '<th>' . __('States', 'creation-reservoir') . '</th>';
        $output .= '</tr></thead><tbody>';

        $projetSuivi = new ISPAG_Projet_Suivi();
        foreach ($projects as $p) {
            $nextStep = $projetSuivi->get_next_phase($p->hubspot_deal_id);
            $output .= '<tr>';
            $output .= '<td style="background-color:#b8e994;"></td>';
            $output .= '<td>' . esc_html($p->ObjetCommande) . '</td>';

            if ($show_price) {
                $output .= '<td>' . number_format($p->prix_net, 2, ',', ' ') . ' CHF</td>';
            } else {
                $output .= '<td>&mdash;</td>';
            }

            $output .= '<td>' . esc_html($p->contact_name) . '</td>';
            $output .= '<td>' . esc_html($p->nom_entreprise) . '</td>';

            if (!$is_quotation) {
                $progress = (new ISPAG_Projet_Progress_Bar())->get_delivery_progress_bar($p->hubspot_deal_id, 1); // 1 = Cuve
            // $output .= '<td colspan="9">' . $progress . '</td>';
                $output .= '<td>' . $progress . '</td>';
                $output .= '<td>&mdash;</td>';
                $output .= '<td>&mdash;</td>';
            }

            // $bgcolor = !empty($nextStep->Color) ? esc_attr($nextStep->Color) : '#ccc'; // gris clair par défaut
            // $text = __(esc_html($nextStep->TitrePhase),"creation-reservoir");
            // $badge = "<span  class=\"badge bg-{$bgcolor} text-dark\" style=\"--bs-bg-opacity: 0.5; padding: 3px 6px; font-size: 0.8rem;\">{$text}</span>";
            $badge = '&mdash;';
            $output .= '<td>' . $badge . '</td>';
            $output .= '</tr>';
        }

        $output .= '</tbody></table>';

        return $output;
    }

}
